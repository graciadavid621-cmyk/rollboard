package com.rollkeyboard;

import java.util.ArrayList;
import java.util.List;

import static com.rollkeyboard.Rarity.*;

public final class Layouts {
    private Layouts() {}

    public static final int M_NORMAL = 0, M_T9 = 1, M_MORSE = 2, M_BIN = 3, M_HEX = 4,
            M_DEC = 5, M_UNI = 6, M_WHEEL = 7, M_WORDS = 8;

    public static final List<LayoutDef> ALL = new ArrayList<>();

    public static LayoutDef byId(String id) {
        for (LayoutDef l : ALL) if (l.id.equals(id)) return l;
        return ALL.get(0);
    }

    private static void addM(String id, String name, Rarity r, int mode, boolean scramble, String... rows) {
        String[][] rr = new String[rows.length][];
        for (int i = 0; i < rows.length; i++) rr[i] = rows[i].trim().split("\\s+");
        ALL.add(new LayoutDef(id, name, r, mode, scramble, rr));
    }

    private static void add(String id, String name, Rarity r, String... rows) {
        addM(id, name, r, M_NORMAL, false, rows);
    }

    private static String[] rng(int from, int to, int per) {
        List<String> rows = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (int cp = from; cp <= to; cp++) {
            if (n == per) {
                rows.add(sb.toString());
                sb.setLength(0);
                n = 0;
            }
            if (n > 0) sb.append(' ');
            sb.appendCodePoint(cp);
            n++;
        }
        if (n > 0) rows.add(sb.toString());
        return rows.toArray(new String[0]);
    }

    static {
        // ---------------- COMMON ----------------
        add("qwerty", "QWERTY", COMMON,
                "q w e r t y u i o p", "a s d f g h j k l", "z x c v b n m");
        add("qwertz", "QWERTZ (German)", COMMON,
                "q w e r t z u i o p ü", "a s d f g h j k l ö ä", "y x c v b n m");
        add("azerty", "AZERTY (French)", COMMON,
                "a z e r t y u i o p", "q s d f g h j k l m", "w x c v b n");
        add("qwerty_es", "QWERTY Español (ñ)", COMMON,
                "q w e r t y u i o p", "a s d f g h j k l ñ", "z x c v b n m");
        add("qwerty_pt", "QWERTY Português (ç)", COMMON,
                "q w e r t y u i o p", "a s d f g h j k l ç", "z x c v b n m");
        add("top_row", "Top Row Only", COMMON,
                "q w e r t y u i o p");

        // ---------------- UNCOMMON ----------------
        add("qwerty_nordic", "Nordic QWERTY (å ö ä)", UNCOMMON,
                "q w e r t y u i o p å", "a s d f g h j k l ö ä", "z x c v b n m");
        add("qwerty_tr", "Turkish Q", UNCOMMON,
                "q w e r t y u ı o p ğ ü", "a s d f g h j k l ş i", "z x c v b n m ö ç");
        add("dvorak", "Dvorak", UNCOMMON,
                "' , . p y f g c r l", "a o e u i d h t n s", "; q j k x b m w v z");
        add("colemak", "Colemak", UNCOMMON,
                "q w f p g j l u y ;", "a r s t d h n e i o", "z x c v b k m");
        add("bepo", "BÉPO", UNCOMMON,
                "b é p o è v d l j z", "a u i e c t s r n m", "ê à y x k q g h f w");
        add("alphabetical", "Alphabetical (ABC)", UNCOMMON,
                "a b c d e f g h i j", "k l m n o p q r s t", "u v w x y z");
        add("vowels_first", "Vowels First", UNCOMMON,
                "a e i o u", "b c d f g h j", "k l m n p q r", "s t v w x y z");
        add("frequency", "Frequency Order", UNCOMMON,
                "e t a o i n s h r d", "l c u m w f g y p b", "v k j x q z");
        add("backwards_qwerty", "Backwards QWERTY", UNCOMMON,
                "p o i u y t r e w q", "l k j h g f d s a", "m n b v c x z");
        add("home_row", "Home Row Only", UNCOMMON,
                "a s d f g h j k l");
        add("punct_party", "Punctuation Only", UNCOMMON,
                ". , ! ? ' : ; - ( )", "/ @ # & * + = _ ~ ^");

        // ---------------- RARE ----------------
        add("workman", "Workman", RARE,
                "q d r w b j f u p ;", "a s h t g y n e o i", "z x m c v k l , .");
        add("norman", "Norman", RARE,
                "q w d f k j u r l ;", "a s e t g y n i o h", "z x c v b p m , .");
        add("colemak_dh", "Colemak-DH", RARE,
                "q w f p b j l u y ;", "a r s t g m n e i o", "x c d v z k h , .");
        add("neo2", "Neo 2", RARE,
                "x v l c w k h g f q", "u i a e o s n r t d", "ü ö ä p z b m , . j");
        add("halmak", "Halmak", RARE,
                "w l r b z ; q u d j", "s h n t , . a e o i", "f m v c / g p x k y");
        add("asset", "Asset", RARE,
                "q w j f g y p u l ;", "a s e t d h n i o r", "z x c v b k m , .");
        add("carpalx", "Carpalx QGMLWY", RARE,
                "q g m l w y f u b ;", "d s t n r i a e o h", "z x c v j k p , .");
        add("reverse_alpha", "Reverse Alphabet", RARE,
                "z y x w v u t s r q", "p o n m l k j i h g", "f e d c b a");
        add("snake_alpha", "Alphabet Snake", RARE,
                "a b c d e f g h i j", "t s r q p o n m l k", "u v w x y z");
        add("flipped_qwerty", "Flipped QWERTY (rows upside-down)", RARE,
                "z x c v b n m", "a s d f g h j k l", "q w e r t y u i o p");
        add("five_col", "Five Columns", RARE,
                "a b c d e", "f g h i j", "k l m n o", "p q r s t", "u v w x y", "z");
        add("left_hand", "Left Hand Only", RARE,
                "q w e r t", "a s d f g", "z x c v b");
        add("right_hand", "Right Hand Only", RARE,
                "y u i o p", "h j k l", "n m");
        add("only_vowels", "Vowels Only", RARE,
                "a e i o u y");
        add("numpad", "Numpad", RARE,
                "1 2 3", "4 5 6", "7 8 9", "0 . ,");
        addM("t9", "Flip Phone T9 Multi-Tap", RARE, M_T9, false,
                "abc def ghi", "jkl mno pqrs", "tuv wxyz .,?!");
        addM("scramble_qwerty", "Scrambled QWERTY (fixed per roll)", RARE, M_NORMAL, true,
                "q w e r t y u i o p", "a s d f g h j k l", "z x c v b n m");
        add("jcuken", "Russian ЙЦУКЕН", RARE,
                "й ц у к е н г ш щ з х", "ф ы в а п р о л д ж э", "я ч с м и т ь б ю");
        add("ukrainian", "Ukrainian", RARE,
                "й ц у к е н г ш щ з х ї", "ф і в а п р о л д ж є", "я ч с м и т ь б ю ґ");
        add("bulgarian", "Bulgarian Phonetic", RARE,
                "я в е р т ъ у и о п ч", "а с д ф г х й к л ш", "з ь ц ж б н м");
        add("greek", "Greek", RARE,
                "ς ε ρ τ υ θ ι ο π", "α σ δ φ γ η ξ κ λ", "ζ χ ψ ω β ν μ");
        add("zodiac", "Zodiac Signs", RARE, rng(0x2648, 0x2653, 6));
        add("chess", "Chess Pieces", RARE, rng(0x2654, 0x265F, 6));
        add("emoji_faces", "Emoji Faces", RARE, rng(0x1F600, 0x1F627, 10));
        add("emoji_animals", "Animal Kingdom", RARE, rng(0x1F400, 0x1F427, 10));
        add("emoji_food", "Food Court", RARE, rng(0x1F345, 0x1F36C, 10));
        add("circled_nums", "Circled Numbers", RARE, rng(0x2776, 0x2793, 10));
        addM("doge", "Doge Speak", RARE, M_WORDS, false,
                "wow much so very such", "amazing scare concern shibe doge", "plz nice many pls moon");
        addM("yesno", "Yes / No / Maybe", RARE, M_WORDS, false,
                "yes no maybe idk lol", "ok sure nope fine whatever");

        // ---------------- EPIC ----------------
        add("only_consonants", "Consonants Only", EPIC,
                "b c d f g h j", "k l m n p q r", "s t v w x z");
        add("one_row", "Tiny Single Row (26 keys!)", EPIC,
                "q w e r t y u i o p a s d f g h j k l z x c v b n m");
        add("serbian", "Serbian Cyrillic", EPIC,
                "љ њ е р т з у и о п ш ђ", "а с д ф г х ј к л ч ћ ж", "ѕ џ ц в б н м");
        add("hebrew", "Hebrew", EPIC,
                "ק ר א ט ו ן ם פ", "ש ד ג כ ע י ח ל ך ף", "ז ס ב ה נ מ צ ת ץ");
        add("arabic", "Arabic", EPIC,
                "ض ص ث ق ف غ ع ه خ ح ج", "ش س ي ب ل ا ت ن م ك", "ئ ء ؤ ر ى ة و ز ظ");
        add("persian", "Persian", EPIC,
                "ض ص ث ق ف غ ع ه خ ح ج چ", "ش س ی ب ل ا ت ن م ک گ", "ظ ط ز ر ذ د پ و");
        add("thai", "Thai Consonants", EPIC,
                "ก ข ค ง จ ฉ ช ซ ด ต", "ถ ท ธ น บ ป ผ ฝ พ ฟ", "ม ย ร ล ว ศ ส ห อ ฮ");
        add("devanagari", "Devanagari", EPIC,
                "क ख ग घ ङ च छ ज झ ञ", "ट ठ ड ढ ण त थ द ध न", "प फ ब भ म य र ल व श", "स ह अ आ इ ई उ ऊ ए ओ");
        add("hiragana", "Hiragana", EPIC,
                "あ い う え お か き く け こ", "さ し す せ そ た ち つ て と", "な に ぬ ね の は ひ ふ へ ほ",
                "ま み む め も や ゆ よ ら り", "る れ ろ わ を ん ー っ ゃ ゅ ょ");
        add("katakana", "Katakana", EPIC,
                "ア イ ウ エ オ カ キ ク ケ コ", "サ シ ス セ ソ タ チ ツ テ ト", "ナ ニ ヌ ネ ノ ハ ヒ フ ヘ ホ",
                "マ ミ ム メ モ ヤ ユ ヨ ラ リ", "ル レ ロ ワ ヲ ン ー ッ ャ ュ ョ");
        add("hangul_jamo", "Hangul Jamo", EPIC,
                "ㅂ ㅈ ㄷ ㄱ ㅅ ㅛ ㅕ ㅑ ㅐ ㅔ", "ㅁ ㄴ ㅇ ㄹ ㅎ ㅗ ㅓ ㅏ ㅣ", "ㅋ ㅌ ㅊ ㅍ ㅠ ㅜ ㅡ");
        add("georgian", "Georgian", EPIC,
                "ქ წ ე რ ტ ყ უ ი ო პ", "ა ს დ ფ გ ჰ ჯ კ ლ", "ზ ხ ც ვ ბ ნ მ");
        add("armenian", "Armenian", EPIC,
                "ք ո ե ռ տ ը ւ ի օ պ", "ա ս դ ֆ գ հ յ կ լ", "զ խ ց վ բ ն մ");
        add("bopomofo", "Bopomofo", EPIC, rng(0x3105, 0x3129, 10));
        add("kanji_starter", "Kanji Starter Pack", EPIC,
                "一 二 三 四 五 六 七 八 九 十", "百 千 万 人 大 小 日 月 火 水", "木 金 土 山 川 田 口 目 手 心");
        add("dice_suits", "Dice & Card Suits", EPIC,
                "⚀ ⚁ ⚂ ⚃ ⚄ ⚅", "♠ ♥ ♦ ♣ ♤ ♡ ♢ ♧");
        add("music", "Music Notes", EPIC, "♩ ♪ ♫ ♬ ♭ ♮ ♯");
        add("arrows", "Arrow Overload", EPIC, rng(0x2190, 0x21B7, 10));
        add("box_draw", "Box Drawing", EPIC, rng(0x2500, 0x2527, 10));
        add("shapes", "Geometric Shapes", EPIC, rng(0x25A0, 0x25C7, 10));
        add("misc_symbols", "Weather & Misc Symbols", EPIC, rng(0x2600, 0x2627, 10));
        add("math_ops", "Math Operators", EPIC, rng(0x2200, 0x2227, 10));
        add("iching", "I Ching Hexagrams", EPIC, rng(0x4DC0, 0x4DE7, 10));
        add("clocks", "Clock Faces", EPIC, rng(0x1F550, 0x1F567, 8));
        add("mahjong", "Mahjong Tiles", EPIC, rng(0x1F000, 0x1F021, 9));
        add("dominoes", "Domino Tiles", EPIC, rng(0x1F030, 0x1F057, 10));
        addM("top_words", "Top 20 Words", EPIC, M_WORDS, false,
                "the be to of and", "a in that have i", "it for not on with", "he as you do at");
        addM("uwu_words", "UwU Vocabulary", EPIC, M_WORDS, false,
                "uwu owo nya ~ rawr", ">w< ^w^ :3 hewwo pwease", "sowwy luv cutie smol baka");
        addM("pirate_words", "Pirate Vocabulary", EPIC, M_WORDS, false,
                "arr ahoy matey ye me", "treasure rum ship sea gold", "yo ho sail plank parrot", "avast scurvy booty kraken cap'n");
        addM("calculator", "Calculator", EPIC, M_NORMAL, false,
                "7 8 9 + (", "4 5 6 - )", "1 2 3 * =", "0 . / % ^");
        addM("scramble_alpha", "Scrambled Alphabet (fixed per roll)", EPIC, M_NORMAL, true,
                "a b c d e f g h i j", "k l m n o p q r s t", "u v w x y z");
        addM("scramble_emoji", "Letters & Emoji Scramble", EPIC, M_NORMAL, true,
                "a b c d e f g h i j", "k l m n o p q r s t", "u v w x y z 😀 🔥 💀", "👻 🎃 🦇 🍕 🐱 🦄 ✨ 💖");

        // ---------------- LEGENDARY ----------------
        add("elder_futhark", "Elder Futhark Runes", LEGENDARY,
                "ᚠ ᚢ ᚦ ᚨ ᚱ ᚲ ᚷ ᚹ ᚺ ᚾ", "ᛁ ᛃ ᛇ ᛈ ᛉ ᛊ ᛏ ᛒ ᛖ ᛗ", "ᛚ ᛜ ᛞ ᛟ");
        add("braille", "Braille Alphabet", LEGENDARY,
                "⠁ ⠃ ⠉ ⠙ ⠑ ⠋ ⠛ ⠓ ⠊ ⠚", "⠅ ⠇ ⠍ ⠝ ⠕ ⠏ ⠟ ⠗ ⠎ ⠞", "⠥ ⠧ ⠺ ⠭ ⠽ ⠵");
        add("hieroglyphs", "Egyptian Hieroglyphs", LEGENDARY, rng(0x13000, 0x13027, 10));
        add("cuneiform", "Cuneiform", LEGENDARY, rng(0x12000, 0x12027, 10));
        add("ogham", "Ogham", LEGENDARY, rng(0x1681, 0x169A, 9));
        add("phoenician", "Phoenician", LEGENDARY, rng(0x10900, 0x10915, 8));
        add("gothic", "Gothic", LEGENDARY, rng(0x10330, 0x10349, 9));
        add("cherokee", "Cherokee", LEGENDARY, rng(0x13A0, 0x13C7, 10));
        add("canadian", "Canadian Syllabics", LEGENDARY, rng(0x1401, 0x1428, 10));
        add("tifinagh", "Tifinagh", LEGENDARY, rng(0x2D30, 0x2D55, 10));
        add("glagolitic", "Glagolitic", LEGENDARY, rng(0x2C00, 0x2C1B, 10));
        add("kangxi", "Kangxi Radicals", LEGENDARY, rng(0x2F00, 0x2F27, 10));
        add("deseret", "Deseret", LEGENDARY, rng(0x10400, 0x10427, 10));
        add("shavian", "Shavian", LEGENDARY, rng(0x10450, 0x10467, 8));
        add("yi", "Yi Syllables", LEGENDARY, rng(0xA000, 0xA027, 10));
        addM("caveman", "Caveman Vocabulary", LEGENDARY, M_WORDS, false,
                "ug ooga booga me want", "food fire rock club bad", "good sleep hunt mammoth no", "yes you big small cave");
        addM("corporate", "Corporate Buzzwords", LEGENDARY, M_WORDS, false,
                "synergy leverage pivot align circleback", "bandwidth scalable agile stakeholder paradigm",
                "ideate roadmap onboard disrupt ecosystem");
        addM("bigrams", "Bigram Keyboard", LEGENDARY, M_NORMAL, false,
                "th he in er an re on at en nd", "ti es or te of ed is it al ar",
                "st to nt ng se ha as ou io le", "ve co me de hi ri ro a e i o u");
        addM("syllables", "Romaji Syllables", LEGENDARY, M_NORMAL, false,
                "ka ki ku ke ko sa shi su se so", "ta chi tsu te to na ni nu ne no",
                "ha hi fu he ho ma mi mu me mo", "ya yu yo ra ri ru re ro wa n", "a i u e o");
        addM("lorem", "Lorem Ipsum Keyboard", LEGENDARY, M_WORDS, false,
                "lorem ipsum dolor sit amet", "consectetur adipiscing elit sed do",
                "eiusmod tempor ut labore et", "dolore magna aliqua enim minim");
        addM("arcade_wheel", "Arcade Initials Wheel", LEGENDARY, M_WHEEL, false,
                "⏪ ◀ ▶ ⏩", "✓");
        addM("scramble_soup", "Alphabet Soup (Latin/Greek/Cyrillic scramble)", LEGENDARY, M_NORMAL, true,
                "a б c δ e φ g н i ж", "к l м n ο p q ρ s т", "υ v ш x ψ z ω я ч ё");

        // ---------------- MYTHIC ----------------
        addM("morse", "Morse Code Paddle", MYTHIC, M_MORSE, false, "• —", "✓");
        addM("binary", "Binary ASCII (8-bit)", MYTHIC, M_BIN, false, "0 1");
        addM("hex", "Hex ASCII (2 digits)", MYTHIC, M_HEX, false,
                "0 1 2 3 4 5 6 7", "8 9 a b c d e f");
        addM("ascii_dec", "Decimal ASCII Code Entry", MYTHIC, M_DEC, false,
                "1 2 3 4 5", "6 7 8 9 0", "✓");
        addM("unicode_hex", "Unicode Code Point Entry", MYTHIC, M_UNI, false,
                "0 1 2 3 4 5 6 7", "8 9 a b c d e f", "✓");
        addM("mystery_keys", "Mystery Keys (every key = random letter)", MYTHIC, M_NORMAL, false,
                "§R §R §R §R §R §R §R §R §R §R", "§R §R §R §R §R §R §R §R §R", "§R §R §R §R §R §R §R");
        addM("vowel_roulette", "Vowel / Consonant Roulette", MYTHIC, M_NORMAL, false,
                "§V §V §V §V §V", "§C §C §C §C §C §C §C", "§C §C §C §C §C §C §C");

        // ---------------- DEVILISH ----------------
        add("pyramid", "Pyramid Scheme (staircase of keys)", DEVILISH,
                "q", "w e", "r t y", "u i o p", "a s d f g", "h j k l z", "x c v b n m");
        addM("fresh_scramble", "Fresh Scramble (re-scrambles EVERY time you open it)", DEVILISH, M_NORMAL, true,
                "q w e r t y u i o p", "a s d f g h j k l", "z x c v b n m");

        // ---------------- CURSED ----------------
        addM("meow_only", "Meow Only", CURSED, M_NORMAL, false,
                "m e o w", "p u r r", "🐱 😺 😸 🐾 🐟");
        addM("word_slots", "Word Slot Machine (random words)", CURSED, M_NORMAL, false,
                "§W §W §W", "§W §W §W");
        addM("emoji_roulette", "Emoji Roulette", CURSED, M_NORMAL, false,
                "§E §E §E §E §E", "§E §E §E §E §E", "§E §E §E §E §E");
        addM("one_button", "The One Button (random letter)", CURSED, M_NORMAL, false, "§R");
        add("two_keys", "Two-Key Wonder (e and t)", CURSED, "e t");
    }
}
