package com.rollkeyboard;

import java.util.ArrayList;
import java.util.List;

import static com.rollkeyboard.Rarity.*;

public final class Themes {
    private Themes() {}

    public static final List<ThemeDef> ALL = new ArrayList<>();

    private static void t(String id, String name, Rarity r, int bg, int key, int text, int mod) {
        ALL.add(new ThemeDef(id, name, r, bg, key, text, mod));
    }

    public static ThemeDef byId(String id) {
        for (ThemeDef t : ALL) if (t.id.equals(id)) return t;
        return ALL.get(0);
    }

    static {
        t("classic_dark", "Classic Dark", COMMON, 0xFF1B1B1F, 0xFF3A3A42, 0xFFFFFFFF, 0xFF2A2A31);
        t("classic_light", "Classic Light", COMMON, 0xFFD8DADF, 0xFFFFFFFF, 0xFF111111, 0xFFB9BDC6);
        t("midnight", "Midnight", COMMON, 0xFF0B1020, 0xFF1C2541, 0xFFE0E6FF, 0xFF121A33);
        t("paper", "Paper", COMMON, 0xFFEFE8D8, 0xFFFBF6EA, 0xFF3A3226, 0xFFD9CFB8);
        t("slate", "Slate", COMMON, 0xFF2B3036, 0xFF414852, 0xFFEEF1F4, 0xFF343A42);

        t("ocean", "Ocean", UNCOMMON, 0xFF0A3D62, 0xFF1E6091, 0xFFEAF6FF, 0xFF0F4C75);
        t("forest", "Forest", UNCOMMON, 0xFF14281D, 0xFF2D4A33, 0xFFE6F4E6, 0xFF1D3A28);
        t("sunset", "Sunset", UNCOMMON, 0xFF3A1C2E, 0xFFE76F51, 0xFFFFF3E0, 0xFFB5495B);
        t("lavender", "Lavender", UNCOMMON, 0xFF2D2342, 0xFF6C5B9E, 0xFFF3ECFF, 0xFF4A3B70);
        t("mint", "Mint", UNCOMMON, 0xFFD5F2E3, 0xFFFFFFFF, 0xFF14532D, 0xFF9BD6B8);
        t("coffee", "Coffee", UNCOMMON, 0xFF2B1B12, 0xFF5A3D2B, 0xFFF5E6D3, 0xFF3E2A1C);
        t("rose", "Rose", UNCOMMON, 0xFFFFE4EC, 0xFFFFFFFF, 0xFF7A1F3D, 0xFFF4B6C8);

        t("neon_pink", "Neon Pink", RARE, 0xFF12001F, 0xFFFF2E93, 0xFF12001F, 0xFF3A0A5C);
        t("cyber_yellow", "Cyber Yellow", RARE, 0xFF0D0D0D, 0xFFFFE600, 0xFF0D0D0D, 0xFF2B2B2B);
        t("terminal_green", "Terminal Green", RARE, 0xFF000000, 0xFF001A00, 0xFF33FF33, 0xFF003300);
        t("gameboy", "Game Boy", RARE, 0xFF0F380F, 0xFF8BAC0F, 0xFF0F380F, 0xFF306230);
        t("vaporwave", "Vaporwave", RARE, 0xFF2B0F54, 0xFFFF71CE, 0xFF2B0F54, 0xFF01CDFE);
        t("synthwave", "Synthwave", RARE, 0xFF1A0B2E, 0xFF3D1E6D, 0xFFFF6AC1, 0xFF2A1450);
        t("ice", "Ice", RARE, 0xFFE8F6FF, 0xFFFFFFFF, 0xFF0B3C5D, 0xFFBFE3F7);
        t("autumn", "Autumn", RARE, 0xFF3B1F0E, 0xFFB5532A, 0xFFFFE8C2, 0xFF7A3A1A);

        t("blood_moon", "Blood Moon", EPIC, 0xFF1A0000, 0xFF5C0A0A, 0xFFFFD6D6, 0xFF330000);
        t("toxic", "Toxic Waste", EPIC, 0xFF0E1A00, 0xFF9DFF00, 0xFF0E1A00, 0xFF2C4A00);
        t("royal_gold", "Royal Gold", EPIC, 0xFF1A1033, 0xFFD4AF37, 0xFF1A1033, 0xFF3B2A6B);
        t("candy", "Candy Shop", EPIC, 0xFFFFD1F0, 0xFF9AF5FF, 0xFF7A0B63, 0xFFFFF59D);
        t("matrix", "Matrix", EPIC, 0xFF000000, 0xFF002200, 0xFF00FF41, 0xFF001100);
        t("amber_crt", "Amber CRT", EPIC, 0xFF0A0600, 0xFF1F1200, 0xFFFFB000, 0xFF140C00);
        t("sepia", "Old Photograph", EPIC, 0xFF704214, 0xFFC9A66B, 0xFF2B1A0A, 0xFF8F5E2D);
        t("deep_space", "Deep Space", EPIC, 0xFF000010, 0xFF16163A, 0xFFB5B5FF, 0xFF0A0A24);

        t("hot_lava", "Hot Lava", LEGENDARY, 0xFF200000, 0xFFFF4500, 0xFFFFFF00, 0xFF8B0000);
        t("golden_hour", "Golden Hour", LEGENDARY, 0xFF442200, 0xFFFFC857, 0xFF442200, 0xFFE08E0B);
        t("aurora", "Aurora", LEGENDARY, 0xFF001A1A, 0xFF00E5A0, 0xFF001A1A, 0xFF6C4DFF);
        t("holographic", "Holographic", LEGENDARY, 0xFFB8C6FF, 0xFFFFD6F6, 0xFF2B2B6B, 0xFFC8FFF0);

        t("void", "The Void (barely visible)", MYTHIC, 0xFF000000, 0xFF050505, 0xFF1A1A1A, 0xFF000000);
        t("blinding_white", "Blinding White", MYTHIC, 0xFFFFFFFF, 0xFFF8F8F8, 0xFFE8E8E8, 0xFFFFFFFF);
        t("highlighter", "Highlighter Overdose", MYTHIC, 0xFFFF2BD6, 0xFFFFFF00, 0xFFFF2BD6, 0xFF00FFFF);

        t("unreadable", "Unreadable Grey", CURSED, 0xFF808080, 0xFF858585, 0xFF8A8A8A, 0xFF7A7A7A);
        t("eye_bleed", "Eye Bleed", CURSED, 0xFFFF0000, 0xFF00FF00, 0xFF0000FF, 0xFFFFFF00);
        t("blue_screen", "Blue Screen of Death", CURSED, 0xFF0000AA, 0xFF0000AA, 0xFFFFFFFF, 0xFF0000AA);
        t("invisible_ink", "Invisible Ink", CURSED, 0xFF202020, 0xFF202020, 0xFF202020, 0xFF202020);
    }
}
