package com.rollkeyboard;

public class Item {
    public final String id;
    public final String name;
    public final Rarity rarity;
    public final String group;

    public Item(String id, String name, Rarity rarity, String group) {
        this.id = id;
        this.name = name;
        this.rarity = rarity;
        this.group = group;
    }
}
