package com.rollkeyboard;

public class LayoutDef extends Item {
    public final String[][] rows;
    public final int mode;
    public final boolean scramble;

    public LayoutDef(String id, String name, Rarity r, int mode, boolean scramble, String[][] rows) {
        super(id, name, r, null);
        this.mode = mode;
        this.scramble = scramble;
        this.rows = rows;
    }

    public boolean noMissing() {
        return mode == Layouts.M_MORSE || mode == Layouts.M_BIN || mode == Layouts.M_WHEEL;
    }

    public boolean bufferMode() {
        return mode >= Layouts.M_MORSE && mode <= Layouts.M_WHEEL;
    }
}
