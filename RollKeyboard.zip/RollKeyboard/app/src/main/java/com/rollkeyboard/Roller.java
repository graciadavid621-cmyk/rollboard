package com.rollkeyboard;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public final class Roller {
    private Roller() {}

    public static final class Result {
        public String layout, font, theme, tier, special;
        public String missingKeys = "";
        public int missingCount, specialMask;
        public long seed;
        public final List<String> features = new ArrayList<>();
        public Rarity best = Rarity.COMMON;
    }

    private static final double[] COUNT_W = {8, 22, 24, 18, 11, 7, 4, 3, 2, 1};

    public static <T extends Item> T pick(List<T> pool, Random r) {
        Rarity[] all = Rarity.values();
        boolean[] has = new boolean[all.length];
        for (T t : pool) has[t.rarity.ordinal()] = true;
        double total = 0;
        for (Rarity ra : all) if (has[ra.ordinal()]) total += ra.weight;
        double x = r.nextDouble() * total;
        Rarity chosen = null;
        for (Rarity ra : all) {
            if (!has[ra.ordinal()]) continue;
            chosen = ra;
            x -= ra.weight;
            if (x <= 0) break;
        }
        List<T> cand = new ArrayList<>();
        for (T t : pool) if (t.rarity == chosen) cand.add(t);
        return cand.get(r.nextInt(cand.size()));
    }

    private static boolean isControl(String t) {
        return t.equals("✓") || t.equals("◀") || t.equals("▶") || t.equals("⏪") || t.equals("⏩")
                || t.equals("•") || t.equals("—");
    }

    private static void best(Result res, Rarity r) {
        if (r.ordinal() > res.best.ordinal()) res.best = r;
    }

    public static Result roll(Random r) {
        Result res = new Result();
        res.seed = r.nextLong();

        LayoutDef L = pick(Layouts.ALL, r);
        FontDef F = pick(Fonts.ALL, r);
        ThemeDef T = pick(Themes.ALL, r);
        MissingDef tier = pick(Missing.TIERS, r);
        MissingDef sp = pick(Missing.SPECIALS, r);
        res.layout = L.id;
        res.font = F.id;
        res.theme = T.id;
        res.tier = tier.id;
        res.special = sp.id;
        res.specialMask = sp.mask;
        best(res, L.rarity);
        best(res, F.rarity);
        best(res, T.rarity);
        best(res, tier.rarity);
        best(res, sp.rarity);

        // missing keys (by position "row:col")
        List<String> elig = new ArrayList<>();
        for (int a = 0; a < L.rows.length; a++)
            for (int b = 0; b < L.rows[a].length; b++)
                if (!isControl(L.rows[a][b])) elig.add(a + ":" + b);
        int k = tier.min + (tier.max > tier.min ? r.nextInt(tier.max - tier.min + 1) : 0);
        int cap = Math.max(0, elig.size() - 3);
        if (L.noMissing()) k = 0;
        k = Math.min(k, cap);
        Collections.shuffle(elig, r);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < k; i++) {
            if (i > 0) sb.append(';');
            sb.append(elig.get(i));
        }
        res.missingKeys = sb.toString();
        res.missingCount = k;

        // features
        double tot = 0;
        for (double w : COUNT_W) tot += w;
        double x = r.nextDouble() * tot;
        int n = 0;
        for (int i = 0; i < COUNT_W.length; i++) {
            x -= COUNT_W[i];
            if (x <= 0) {
                n = i;
                break;
            }
        }
        Set<String> groups = new HashSet<>();
        Set<String> ids = new HashSet<>();
        for (int i = 0; i < n; i++) {
            List<Item> pool = new ArrayList<>();
            for (Item it : Features.ALL) {
                if (ids.contains(it.id)) continue;
                if (it.group != null && groups.contains(it.group)) continue;
                pool.add(it);
            }
            if (pool.isEmpty()) break;
            Item it = pick(pool, r);
            ids.add(it.id);
            if (it.group != null) groups.add(it.group);
            res.features.add(it.id);
            best(res, it.rarity);
        }
        return res;
    }

    private static List<Item> ALL_ITEMS;

    /** Every possible roll, in one pool. */
    public static synchronized List<Item> all() {
        if (ALL_ITEMS == null) {
            List<Item> l = new ArrayList<>();
            l.addAll(Layouts.ALL);
            l.addAll(Fonts.ALL);
            l.addAll(Features.ALL);
            l.addAll(Themes.ALL);
            l.addAll(Missing.TIERS);
            l.addAll(Missing.SPECIALS);
            ALL_ITEMS = l;
        }
        return ALL_ITEMS;
    }

    public static Item pickAny(Random r) {
        return pick(all(), r);
    }

    public static String kindOf(Item it) {
        if (it instanceof LayoutDef) return "L";
        if (it instanceof FontDef) return "F";
        if (it instanceof ThemeDef) return "T";
        if (it instanceof MissingDef) return Missing.TIERS.contains(it) ? "M" : "S";
        return "X";
    }

    public static String kindLabel(String kind) {
        switch (kind) {
            case "L": return "LAYOUT";
            case "F": return "FONT";
            case "T": return "THEME";
            case "M": return "MISSING KEYS";
            case "S": return "SPECIAL KEYS";
            default: return "FEATURE";
        }
    }

    /** Returns {positions, count} of missing letter keys for a layout and tier. */
    public static String[] missing(LayoutDef L, MissingDef tier, Random r) {
        List<String> elig = new ArrayList<>();
        for (int a = 0; a < L.rows.length; a++)
            for (int b = 0; b < L.rows[a].length; b++)
                if (!isControl(L.rows[a][b])) elig.add(a + ":" + b);
        int k = tier.min + (tier.max > tier.min ? r.nextInt(tier.max - tier.min + 1) : 0);
        if (L.noMissing()) k = 0;
        k = Math.min(k, Math.max(0, elig.size() - 3));
        Collections.shuffle(elig, r);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < k; i++) {
            if (i > 0) sb.append(';');
            sb.append(elig.get(i));
        }
        return new String[]{sb.toString(), String.valueOf(k)};
    }
}
