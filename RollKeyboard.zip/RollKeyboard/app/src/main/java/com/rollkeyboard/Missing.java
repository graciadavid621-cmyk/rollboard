package com.rollkeyboard;

import java.util.ArrayList;
import java.util.List;

import static com.rollkeyboard.Rarity.*;

public final class Missing {
    private Missing() {}

    public static final int SHIFT = 1, BKSP = 2, SPACE = 4, ENTER = 8, SYM = 16;

    public static final List<MissingDef> TIERS = new ArrayList<>();
    public static final List<MissingDef> SPECIALS = new ArrayList<>();

    private static void tier(String id, String name, Rarity r, int min, int max) {
        TIERS.add(new MissingDef(id, name, r, min, max, 0));
    }

    private static void sp(String id, String name, Rarity r, int mask) {
        SPECIALS.add(new MissingDef(id, name, r, 0, 0, mask));
    }

    static {
        tier("none", "Complete set (no letters missing)", COMMON, 0, 0);
        tier("m1", "1 key missing", COMMON, 1, 1);
        tier("m2", "2 keys missing", UNCOMMON, 2, 2);
        tier("m3", "3-4 keys missing", UNCOMMON, 3, 4);
        tier("m5", "5-7 keys missing", RARE, 5, 7);
        tier("m8", "8-11 keys missing", EPIC, 8, 11);
        tier("m12", "12-16 keys missing", LEGENDARY, 12, 16);
        tier("m17", "17-22 keys missing", MYTHIC, 17, 22);
        tier("mall", "Skeleton keyboard (all but 3 keys gone)", CURSED, 99, 99);

        sp("sp_none", "All special keys present", COMMON, 0);
        sp("sp_noshift", "No Shift key", UNCOMMON, SHIFT);
        sp("sp_nosym", "No ?123 key", UNCOMMON, SYM);
        sp("sp_noenter", "No Enter key", RARE, ENTER);
        sp("sp_noshiftsym", "No Shift and no ?123", RARE, SHIFT | SYM);
        sp("sp_nospace", "No Space bar", EPIC, SPACE);
        sp("sp_nobksp", "No Backspace", LEGENDARY, BKSP);
        sp("sp_nospacebksp", "No Space and no Backspace", MYTHIC, SPACE | BKSP);
        sp("sp_bare", "Letters only (no specials at all)", CURSED, SHIFT | BKSP | SPACE | ENTER | SYM);
    }

    public static MissingDef byId(List<MissingDef> list, String id) {
        for (MissingDef m : list) if (m.id.equals(id)) return m;
        return list.get(0);
    }
}
