package com.rollkeyboard;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class FontDef extends Item {
    public static final int PLAIN = 0, OFFSET = 1, INDEX = 2, TABLE = 3, COMBINE = 4,
            ZALGO = 5, WRAP = 6, SPACED = 7, ENCODE = 8;
    private static final Random RND = new Random();

    public final int type;
    public int upper, lower, digit, step = 1, level;
    public final Map<Integer, Integer> exc = new HashMap<>();
    public String[] table, tableUp;
    public String dig;
    public String extra = "";
    public boolean reverseInsert;

    public FontDef(String id, String name, Rarity r, int type) {
        super(id, name, r, null);
        this.type = type;
    }

    public String apply(String in) {
        if (type == PLAIN || in == null) return in;
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < in.length()) {
            int cp = in.codePointAt(i);
            i += Character.charCount(cp);
            boolean up = cp >= 'A' && cp <= 'Z';
            boolean lo = cp >= 'a' && cp <= 'z';
            boolean dg = cp >= '0' && cp <= '9';
            if (!(up || lo || dg)) {
                sb.appendCodePoint(cp);
                continue;
            }
            int idx = up ? cp - 'A' : (lo ? cp - 'a' : -1);
            switch (type) {
                case OFFSET: {
                    Integer e = exc.get(cp);
                    int out;
                    if (e != null) out = e;
                    else if (up) out = upper + idx;
                    else if (lo) out = lower + idx;
                    else out = digit != 0 ? digit + (cp - '0') : cp;
                    sb.appendCodePoint(out);
                    break;
                }
                case INDEX: {
                    if (idx >= 0) sb.appendCodePoint((up ? upper : (lower != 0 ? lower : upper)) + idx * step);
                    else sb.appendCodePoint(cp);
                    break;
                }
                case TABLE: {
                    if (idx >= 0) {
                        String[] t = (up && tableUp != null) ? tableUp : table;
                        sb.append(t[idx]);
                    } else if (dig != null) {
                        sb.append(dig.charAt(cp - '0'));
                    } else {
                        sb.appendCodePoint(cp);
                    }
                    break;
                }
                case COMBINE:
                case SPACED:
                    sb.appendCodePoint(cp).append(extra);
                    break;
                case ZALGO: {
                    sb.appendCodePoint(cp);
                    int n = level * 2 + RND.nextInt(level + 1);
                    for (int k = 0; k < n; k++) sb.appendCodePoint(0x300 + RND.nextInt(0x70));
                    break;
                }
                case WRAP: {
                    int bar = extra.indexOf('|');
                    sb.append(extra.substring(0, bar)).appendCodePoint(cp).append(extra.substring(bar + 1));
                    break;
                }
                case ENCODE: {
                    if ("bin".equals(extra)) {
                        String s = Integer.toBinaryString(cp);
                        while (s.length() < 8) s = "0" + s;
                        sb.append(s).append(' ');
                    } else if ("hex".equals(extra)) {
                        sb.append(Integer.toHexString(cp)).append(' ');
                    } else if (idx >= 0) {
                        sb.append(table[idx]).append(' ');
                    } else {
                        sb.appendCodePoint(cp);
                    }
                    break;
                }
                default:
                    sb.appendCodePoint(cp);
            }
        }
        return sb.toString();
    }
}
