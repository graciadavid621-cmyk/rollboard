package com.rollkeyboard;

public class MissingDef extends Item {
    public final int min, max, mask;

    public MissingDef(String id, String name, Rarity r, int min, int max, int mask) {
        super(id, name, r, null);
        this.min = min;
        this.max = max;
        this.mask = mask;
    }
}
