package com.rollkeyboard;

public final class Blessings {
    private Blessings() {}

    public static final String[] NAMES = {
            "Full Restoration",
            "Purify Features",
            "Keys Returned",
            "Font Cleanse",
            "Layout Reset",
            "Theme Reset",
            "Half Cleanse",
            "Lighten the Load"
    };
}
