package com.rollkeyboard;

import java.util.HashMap;
import java.util.Map;

public final class Words {
    private Words() {}

    public static final String[] EMOJIS = {
            "😀", "😂", "🥹", "😎", "🤯", "🥳", "😭", "🤔", "🙃", "😈", "👀", "👍", "👏", "🔥", "✨", "💀",
            "👻", "🎃", "🦇", "🌈", "🍕", "🍔", "🍟", "🌮", "🍩", "🍪", "🐱", "🐶", "🦄", "🐸", "🐙", "🦆",
            "🐝", "🌵", "🌻", "🍄", "⭐", "🌙", "⚡", "💎", "🎲", "🎮", "🎸", "🚀", "🛸", "💖", "💯", "🧠",
            "🫠", "🤡", "💩"};

    public static final String[] SILLY = {
            "banana", "potato", "wombat", "kazoo", "noodle", "gizmo", "bamboozle", "flapjack", "spork",
            "moist", "yeet", "bruh", "blorp", "zesty", "gobbledygook", "pickle", "walrus", "squid",
            "cabbage", "bingo", "doodle", "snorkel", "waffle", "turnip", "llama", "crumpet", "fiddlesticks",
            "hullabaloo", "wiggle", "pancake", "jellybean", "sassafras", "mango", "unicycle", "taco",
            "yodel", "nugget", "ferret", "glitch", "sock", "hamster", "lasagna", "banjo", "trombone"};

    public static final String[] SUGGEST = {
            "the", "and", "banana", "yeet", "sus", "lol", "indeed", "perhaps", "moist", "bruh", "potato",
            "however", "wombat", "honestly", "literally", "cheese", "vibes", "ok", "no", "yes", "maybe",
            "sorry", "thanks", "hello", "goodbye", "spaghetti", "quantum", "tomorrow", "yesterday", "pizza",
            "meow", "woof", "beep", "boop", "doom", "bingo", "cringe", "based", "gremlin", "cursed"};

    /** Meme videos opened by the Rickroll Roulette feature. Edit freely. */
    public static final String[] MEMES = {
            "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            "https://www.youtube.com/watch?v=QH2-TGUlwu4",
            "https://www.youtube.com/watch?v=_OBlgSz8sSM",
            "https://www.youtube.com/watch?v=9bZkp7q19f0",
            "https://www.youtube.com/watch?v=J---aiyznGQ",
            "https://www.youtube.com/watch?v=2Z4m4lnjxkY",
            "https://www.youtube.com/watch?v=y6120QOlsfU",
            "https://www.youtube.com/watch?v=KmtzQCSh6xk",
            "https://www.youtube.com/watch?v=L_jWHffIx5E",
            "https://www.youtube.com/watch?v=mLyOj_QD4a4",
            "https://www.youtube.com/watch?v=OQSNhk5ICTI",
            "https://www.youtube.com/watch?v=a1Y73sPHKxw",
            "https://www.youtube.com/watch?v=kxopViU98Xo",
            "https://www.youtube.com/watch?v=ZXsQAXx_ao0",
            "https://www.youtube.com/watch?v=XqZsoesa55w",
            "https://www.youtube.com/watch?v=Ct6BUPvE2sM",
            "https://www.youtube.com/watch?v=dMH0bHeiRNg",
            "https://www.youtube.com/watch?v=FzRH3iTQPrk",
            "https://www.youtube.com/watch?v=txqiwrbYGrs",
            "https://www.youtube.com/watch?v=kfVsfOSbJY0",
            "https://www.youtube.com/watch?v=k85mRPqvMbE",
            "https://www.youtube.com/watch?v=MtN1YnoL46Q",
            "https://www.youtube.com/results?search_query=funniest+meme+compilation",
            "https://www.youtube.com/results?search_query=rickroll",
            "https://www.youtube.com/results?search_query=classic+internet+memes",
            "https://www.youtube.com/results?search_query=vine+compilation+meme",
            "https://www.youtube.com/results?search_query=cursed+memes+video",
            "https://www.youtube.com/results?search_query=bruh+sound+effect+meme"};

    public static final String[] FILLERS = {"um", "like", "uh", "you know", "basically", "literally", "so yeah"};

    public static final String[] NUM_WORDS = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};

    public static final Map<String, String> EMOJI_MAP = new HashMap<>();
    public static final Map<String, String> SHAKES = new HashMap<>();
    public static final Map<String, String> PIRATE = new HashMap<>();

    public static final String[] MORSE_L = {
            ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--",
            "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--.."};
    public static final String[] MORSE_D = {
            "-----", ".----", "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----."};
    public static final Map<String, String> MORSE_REV = new HashMap<>();

    private static void p(Map<String, String> m, String... kv) {
        for (int i = 0; i + 1 < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
    }

    static {
        p(EMOJI_MAP, "love", "❤️", "cat", "🐱", "dog", "🐶", "fire", "🔥", "happy", "😀", "sad", "😢",
                "sun", "☀️", "moon", "🌙", "star", "⭐", "pizza", "🍕", "burger", "🍔", "money", "💰",
                "heart", "❤️", "laugh", "😂", "cool", "😎", "party", "🥳", "ghost", "👻", "skull", "💀",
                "rocket", "🚀", "rain", "🌧️", "snow", "❄️", "music", "🎵", "game", "🎮", "car", "🚗",
                "house", "🏠", "tree", "🌳", "flower", "🌸", "coffee", "☕", "beer", "🍺", "cake", "🎂",
                "gift", "🎁", "idea", "💡", "time", "⏰", "phone", "📱", "book", "📖", "eyes", "👀",
                "yes", "✅", "no", "❌", "ok", "👌", "hello", "👋");
        p(SHAKES, "you", "thou", "your", "thy", "are", "art", "my", "mine", "yes", "aye", "no", "nay",
                "hello", "hark", "the", "ye", "is", "be", "do", "doth", "has", "hath", "friend", "companion",
                "very", "most");
        p(PIRATE, "hello", "ahoy", "friend", "matey", "yes", "aye", "my", "me", "the", "th'", "you", "ye",
                "is", "be", "are", "be", "money", "doubloons", "stop", "avast", "food", "grub", "drink", "grog",
                "boat", "ship");
        String l = "abcdefghijklmnopqrstuvwxyz";
        for (int i = 0; i < 26; i++) MORSE_REV.put(MORSE_L[i], String.valueOf(l.charAt(i)));
        for (int i = 0; i < 10; i++) MORSE_REV.put(MORSE_D[i], String.valueOf((char) ('0' + i)));
    }
}
