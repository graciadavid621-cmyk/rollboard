package com.rollkeyboard;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.rollkeyboard.Rarity.*;

public final class Fonts {
    private Fonts() {}

    public static final List<FontDef> ALL = new ArrayList<>();

    public static FontDef byId(String id) {
        for (FontDef f : ALL) if (f.id.equals(id)) return f;
        return ALL.get(0);
    }

    private static FontDef def(String id, String name, Rarity r, int type) {
        FontDef d = new FontDef(id, name, r, type);
        ALL.add(d);
        return d;
    }

    private static void off(String id, String name, Rarity r, int up, int lo, int dg, String exc) {
        FontDef d = def(id, name, r, FontDef.OFFSET);
        d.upper = up;
        d.lower = lo;
        d.digit = dg;
        if (exc != null && !exc.isEmpty()) {
            for (String p : exc.split(",")) {
                d.exc.put((int) p.charAt(0), Integer.parseInt(p.substring(2), 16));
            }
        }
    }

    private static void idx(String id, String name, Rarity r, int base, int step) {
        FontDef d = def(id, name, r, FontDef.INDEX);
        d.upper = base;
        d.step = step;
    }

    private static void comb(String id, String name, Rarity r, int mark) {
        FontDef d = def(id, name, r, FontDef.COMBINE);
        d.extra = new String(Character.toChars(mark));
    }

    private static void wrap(String id, String name, Rarity r, String lr) {
        FontDef d = def(id, name, r, FontDef.WRAP);
        d.extra = lr;
    }

    private static void spaced(String id, String name, Rarity r, String gap) {
        FontDef d = def(id, name, r, FontDef.SPACED);
        d.extra = gap;
    }

    private static void zalgo(String id, String name, Rarity r, int level, boolean rev) {
        FontDef d = def(id, name, r, FontDef.ZALGO);
        d.level = level;
        d.reverseInsert = rev;
    }

    private static String[] tbl(String s) {
        return s.trim().split("\\s+");
    }

    private static FontDef tab(String id, String name, Rarity r, String lower, String upper, String digits, boolean rev) {
        FontDef d = def(id, name, r, FontDef.TABLE);
        d.table = tbl(lower);
        d.tableUp = upper == null ? null : tbl(upper);
        d.dig = digits;
        d.reverseInsert = rev;
        return d;
    }

    private static void map(String id, String name, Rarity r, String spec, boolean derive) {
        FontDef d = def(id, name, r, FontDef.TABLE);
        String[] lo = new String[26];
        String[] up = new String[26];
        for (int i = 0; i < 26; i++) {
            lo[i] = String.valueOf((char) ('a' + i));
            up[i] = String.valueOf((char) ('A' + i));
        }
        for (String p : spec.trim().split("\\s+")) {
            int eq = p.indexOf('=');
            int i = p.charAt(0) - 'a';
            String v = p.substring(eq + 1);
            lo[i] = v;
            up[i] = derive ? v.toUpperCase(Locale.ROOT) : v;
        }
        d.table = lo;
        d.tableUp = up;
    }

    private static void enc(String id, String name, Rarity r, String kind, String[] table) {
        FontDef d = def(id, name, r, FontDef.ENCODE);
        d.extra = kind;
        d.table = table;
    }

    static {
        // ---------------- COMMON ----------------
        def("plain", "Plain (no font)", COMMON, FontDef.PLAIN);
        off("bold", "Math Bold", COMMON, 0x1D400, 0x1D41A, 0x1D7CE, "");
        off("italic", "Math Italic", COMMON, 0x1D434, 0x1D44E, 0, "h=210E");
        off("sans_bold", "Sans Bold", COMMON, 0x1D5D4, 0x1D5EE, 0x1D7EC, "");
        off("sans", "Sans-Serif", COMMON, 0x1D5A0, 0x1D5BA, 0x1D7E2, "");

        // ---------------- UNCOMMON ----------------
        off("bold_italic", "Bold Italic", UNCOMMON, 0x1D468, 0x1D482, 0, "");
        off("sans_italic", "Sans Italic", UNCOMMON, 0x1D608, 0x1D622, 0, "");
        off("mono", "Monospace", UNCOMMON, 0x1D670, 0x1D68A, 0x1D7F6, "");
        off("script", "Script", UNCOMMON, 0x1D49C, 0x1D4B6, 0,
                "B=212C,E=2130,F=2131,H=210B,I=2110,L=2112,M=2133,R=211B,e=212F,g=210A,o=2134");
        off("double_struck", "Double-Struck", UNCOMMON, 0x1D538, 0x1D552, 0x1D7D8,
                "C=2102,H=210D,N=2115,P=2119,Q=211A,R=211D,Z=2124");
        off("fullwidth", "Fullwidth", UNCOMMON, 0xFF21, 0xFF41, 0xFF10, "");
        off("circled", "Circled", UNCOMMON, 0x24B6, 0x24D0, 0x245F, "0=24EA");
        tab("small_caps", "Small Caps", UNCOMMON,
                "ᴀ ʙ ᴄ ᴅ ᴇ ꜰ ɢ ʜ ɪ ᴊ ᴋ ʟ ᴍ ɴ ᴏ ᴘ ǫ ʀ ꜱ ᴛ ᴜ ᴠ ᴡ x ʏ ᴢ", null, null, false);
        comb("strike", "Strikethrough", UNCOMMON, 0x336);
        comb("underline", "Underline", UNCOMMON, 0x332);
        comb("overline", "Overline", UNCOMMON, 0x305);

        // ---------------- RARE ----------------
        off("fraktur", "Fraktur", RARE, 0x1D504, 0x1D51E, 0, "C=212D,H=210C,I=2111,R=211C,Z=2128");
        off("bold_script", "Bold Script", RARE, 0x1D4D0, 0x1D4EA, 0, "");
        off("bold_fraktur", "Bold Fraktur", RARE, 0x1D56C, 0x1D586, 0, "");
        off("sans_bold_italic", "Sans Bold Italic", RARE, 0x1D63C, 0x1D656, 0, "");
        off("neg_circled", "Negative Circled", RARE, 0x1F150, 0x1F150, 0x2775, "0=24FF");
        off("squared", "Squared", RARE, 0x1F130, 0x1F130, 0, "");
        off("neg_squared", "Negative Squared", RARE, 0x1F170, 0x1F170, 0, "");
        off("parenthesized", "Parenthesized", RARE, 0x249C, 0x249C, 0x2473, "0=30");
        tab("superscript", "Superscript", RARE,
                "ᵃ ᵇ ᶜ ᵈ ᵉ ᶠ ᵍ ʰ ⁱ ʲ ᵏ ˡ ᵐ ⁿ ᵒ ᵖ q ʳ ˢ ᵗ ᵘ ᵛ ʷ ˣ ʸ ᶻ",
                "ᴬ ᴮ ᶜ ᴰ ᴱ ᶠ ᴳ ᴴ ᴵ ᴶ ᴷ ᴸ ᴹ ᴺ ᴼ ᴾ Q ᴿ ˢ ᵀ ᵁ ⱽ ᵂ ˣ ʸ ᶻ", "⁰¹²³⁴⁵⁶⁷⁸⁹", false);
        tab("subscript", "Subscript", RARE,
                "ₐ b c d ₑ f g ₕ ᵢ ⱼ ₖ ₗ ₘ ₙ ₒ ₚ q ᵣ ₛ ₜ ᵤ ᵥ w ₓ y z", null, "₀₁₂₃₄₅₆₇₈₉", false);
        comb("double_underline", "Double Underline", RARE, 0x333);
        comb("slashed", "Slashed Through", RARE, 0x338);
        comb("short_strike", "Short Strike", RARE, 0x335);
        comb("tilde_above", "Tilde Above", RARE, 0x303);
        comb("heavy_metal", "Heavy Metal Umlaut", RARE, 0x308);
        comb("acute", "Acute Accent Everywhere", RARE, 0x301);
        comb("grave", "Grave Accent Everywhere", RARE, 0x300);
        comb("dot_above", "Dot Above", RARE, 0x307);
        comb("dot_below", "Dot Below", RARE, 0x323);
        map("leet", "1337 Speak", RARE, "a=4 e=3 i=1 o=0 s=5 t=7", false);
        spaced("spaced_out", "S p a c e d  O u t", RARE, " ");
        spaced("dotted", "Dotted·Letters·", RARE, "·");
        wrap("brackets_cjk", "【Bracketed】", RARE, "【|】");
        wrap("corner_quotes", "「Corner Quotes」", RARE, "「|」");
        idx("emoji_faces_font", "Smiley Alphabet", RARE, 0x1F600, 1);
        idx("emoji_food_font", "Food Alphabet", RARE, 0x1F345, 1);

        // ---------------- EPIC ----------------
        tab("upside_down", "Upside Down (writes backwards)", EPIC,
                "ɐ q ɔ p ǝ ɟ ƃ ɥ ᴉ ɾ ʞ l ɯ u o d b ɹ s ʇ n ʌ ʍ x ʎ z",
                "∀ ᗺ Ɔ ᗡ Ǝ Ⅎ ⅁ H I ſ ⋊ ˥ W N O Ԁ Ό ᴚ S ⊥ ∩ Λ M X ⅄ Z", "0ƖᄅƐㄣϛ9ㄥ86", true);
        off("regional", "Regional Indicators", EPIC, 0x1F1E6, 0x1F1E6, 0, "");
        zalgo("zalgo1", "Mild Zalgo", EPIC, 1, false);
        comb("keycap", "Keycap Letters", EPIC, 0x20E3);
        comb("enclosing_circle", "Enclosing Circles", EPIC, 0x20DD);
        comb("enclosing_square", "Enclosing Squares", EPIC, 0x20DE);
        comb("enclosing_diamond", "Enclosing Diamonds", EPIC, 0x20DF);
        comb("arrow_above", "Arrow Above", EPIC, 0x20D7);
        comb("x_above", "X Above", EPIC, 0x33D);
        comb("wavy_under", "Wavy Underline", EPIC, 0x330);
        comb("cedilla", "Cedilla Soup", EPIC, 0x327);
        comb("ring", "Ring Above", EPIC, 0x30A);
        comb("hat", "Circumflex Hats", EPIC, 0x302);
        comb("caron", "Caron Wedges", EPIC, 0x30C);
        wrap("lenticular", "⟦Lenticular⟧", EPIC, "⟦|⟧");
        wrap("guillemets", "«Guillemets»", EPIC, "«|»");
        wrap("stars", "★Stars★", EPIC, "★|★");
        wrap("hearts", "♥Hearts♥", EPIC, "♥|♥");
        wrap("flowers", "✿Flowers✿", EPIC, "✿|✿");
        wrap("parens", "(Parens)", EPIC, "(|)");
        wrap("squiggle", "~Squiggle~", EPIC, "~|~");
        spaced("dashed", "D-a-s-h-e-d", EPIC, "-");
        spaced("slashed_gap", "S/l/a/s/h/e/d", EPIC, "/");
        spaced("sparkle", "Sparkle ✨", EPIC, "✨");
        map("homoglyph_cyr", "Cyrillic Lookalikes (sneaky)", EPIC,
                "a=а c=с e=е i=і j=ј o=о p=р s=ѕ x=х y=у", true);
        map("currency", "Currency Letters", EPIC, "a=@ c=¢ e=€ l=£ s=$ y=¥ t=† o=¤ b=฿", false);
        map("greek_translit", "Greek Transliteration", EPIC,
                "a=α b=β c=κ d=δ e=ε f=φ g=γ h=η i=ι j=ι k=κ l=λ m=μ n=ν o=ο p=π q=κ r=ρ s=σ t=τ u=υ v=β w=ω x=ξ y=ψ z=ζ", true);
        map("cyrillic_translit", "Cyrillic Transliteration", EPIC,
                "a=а b=б c=ц d=д e=е f=ф g=г h=х i=и j=й k=к l=л m=м n=н o=о p=п q=к r=р s=с t=т u=у v=в w=в x=кс y=ы z=з", true);
        idx("animals_font", "Animal Alphabet", EPIC, 0x1F400, 1);
        idx("hexagram_font", "Hexagram Alphabet", EPIC, 0x4DC0, 1);
        idx("mahjong_font", "Mahjong Alphabet", EPIC, 0x1F000, 1);
        idx("hiragana_font", "Hiragana Soup", EPIC, 0x3041, 1);
        idx("katakana_font", "Katakana Soup", EPIC, 0x30A1, 1);
        idx("bopomofo_font", "Bopomofo Soup", EPIC, 0x3105, 1);
        idx("zodiac_font", "Zodiac Alphabet", EPIC, 0x2648, 1);

        // ---------------- LEGENDARY ----------------
        zalgo("zalgo2", "Medium Zalgo", LEGENDARY, 2, false);
        map("leet_heavy", "Hardcore 1337", LEGENDARY,
                "a=@ b=8 c=( d=|) e=3 f=|= g=9 h=# i=! j=_| k=|< l=1 m=|v| n=|\\| o=0 p=|> q=9 r=|2 s=$ t=+ u=|_| v=\\/ w=\\/\\/ x=>< y=`/ z=2", false);
        enc("morse_out", "Morse Output (letters become morse)", LEGENDARY, "morse", Words.MORSE_L);
        enc("nato_out", "NATO Phonetic Output", LEGENDARY, "nato", tbl(
                "Alpha Bravo Charlie Delta Echo Foxtrot Golf Hotel India Juliet Kilo Lima Mike November Oscar Papa Quebec Romeo Sierra Tango Uniform Victor Whiskey Xray Yankee Zulu"));
        map("runic_translit", "Runic Transliteration", LEGENDARY,
                "a=ᚨ b=ᛒ c=ᚲ d=ᛞ e=ᛖ f=ᚠ g=ᚷ h=ᚺ i=ᛁ j=ᛃ k=ᚲ l=ᛚ m=ᛗ n=ᚾ o=ᛟ p=ᛈ q=ᚲ r=ᚱ s=ᛊ t=ᛏ u=ᚢ v=ᚹ w=ᚹ x=ᛉ y=ᛃ z=ᛉ", false);
        map("braille_translit", "Braille Transliteration", LEGENDARY,
                "a=⠁ b=⠃ c=⠉ d=⠙ e=⠑ f=⠋ g=⠛ h=⠓ i=⠊ j=⠚ k=⠅ l=⠇ m=⠍ n=⠝ o=⠕ p=⠏ q=⠟ r=⠗ s=⠎ t=⠞ u=⠥ v=⠧ w=⠺ x=⠭ y=⠽ z=⠵", false);
        map("katakana_translit", "Katakana Transliteration", LEGENDARY,
                "a=ア b=ブ c=ク d=ド e=エ f=フ g=グ h=ハ i=イ j=ジ k=ク l=ル m=ム n=ン o=オ p=プ q=ク r=ル s=ス t=ト u=ウ v=ヴ w=ワ x=クス y=ユ z=ズ", false);
        map("hangul_translit", "Hangul Transliteration", LEGENDARY,
                "a=아 b=브 c=크 d=드 e=에 f=프 g=그 h=흐 i=이 j=즈 k=크 l=르 m=므 n=느 o=오 p=프 q=쿠 r=르 s=스 t=트 u=우 v=브 w=와 x=엑 y=이 z=즈", false);
        idx("hieroglyph_font", "Hieroglyph Alphabet", LEGENDARY, 0x13000, 1);
        idx("cuneiform_font", "Cuneiform Alphabet", LEGENDARY, 0x12000, 1);
        idx("dominoes_font", "Domino Alphabet", LEGENDARY, 0x1F030, 1);
        idx("phoenician_font", "Phoenician Alphabet", LEGENDARY, 0x10900, 1);
        idx("gothic_font", "Gothic Alphabet", LEGENDARY, 0x10330, 1);
        idx("old_italic_font", "Old Italic Alphabet", LEGENDARY, 0x10300, 1);
        idx("deseret_font", "Deseret Alphabet", LEGENDARY, 0x10400, 1);
        idx("shavian_font", "Shavian Alphabet", LEGENDARY, 0x10450, 1);
        idx("cherokee_font", "Cherokee Alphabet", LEGENDARY, 0x13A0, 1);
        idx("tifinagh_font", "Tifinagh Alphabet", LEGENDARY, 0x2D30, 1);
        idx("glagolitic_font", "Glagolitic Alphabet", LEGENDARY, 0x2C00, 1);
        idx("runic_range_font", "Runic Block Alphabet", LEGENDARY, 0x16A0, 1);
        tab("backwards_writer", "Backwards Writer (plain letters, typed right-to-left)", LEGENDARY,
                "a b c d e f g h i j k l m n o p q r s t u v w x y z", null, null, true);

        // ---------------- MYTHIC ----------------
        zalgo("zalgo3", "HE COMES (heavy Zalgo)", MYTHIC, 3, false);
        enc("binary_out", "Binary Output (8-bit per char)", MYTHIC, "bin", null);
        enc("hex_out", "Hex Output (byte per char)", MYTHIC, "hex", null);
        idx("canadian_font", "Canadian Syllabics Alphabet", MYTHIC, 0x1401, 1);
        idx("kangxi_font", "Kangxi Radical Alphabet", MYTHIC, 0x2F00, 1);
        idx("ethiopic_font", "Ethiopic Alphabet", MYTHIC, 0x1200, 8);
        idx("hangul_syll_font", "Hangul Syllable Roulette", MYTHIC, 0xAC00, 31);
        idx("cjk_font", "CJK Gibberish", MYTHIC, 0x4E00, 13);

        // ---------------- CURSED ----------------
        zalgo("zalgo_backwards", "Backwards Zalgo", CURSED, 3, true);
        idx("yi_font", "Yi Syllable Alphabet", CURSED, 0xA000, 1);
        idx("cjk_far_font", "Far-Out CJK Noise", CURSED, 0x5000, 97);
        spaced("clap_font", "Clap👏Between👏Letters", CURSED, "👏");
        spaced("fire_font", "Fire🔥Between🔥Letters", CURSED, "🔥");
    }
}
