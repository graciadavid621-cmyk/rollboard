package com.rollkeyboard;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class RollState {
    public String layout = "qwerty", font = "plain", theme = "classic_dark",
            tier = "none", special = "sp_none", missingKeys = "", features = "";
    public int specialMask, missingCount, rollCount, chance = 30;
    public long seed = 1;
    public boolean pending = true;

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("roll_keyboard", Context.MODE_PRIVATE);
    }

    public static RollState load(Context c) {
        SharedPreferences p = sp(c);
        RollState s = new RollState();
        s.layout = p.getString("layout", s.layout);
        s.font = p.getString("font", s.font);
        s.theme = p.getString("theme", s.theme);
        s.tier = p.getString("tier", s.tier);
        s.special = p.getString("special", s.special);
        s.missingKeys = p.getString("missingKeys", "");
        s.features = p.getString("features", "");
        s.specialMask = p.getInt("specialMask", 0);
        s.missingCount = p.getInt("missingCount", 0);
        s.rollCount = p.getInt("rollCount", 0);
        s.chance = p.getInt("chance", 30);
        s.seed = p.getLong("seed", 1);
        s.pending = p.getBoolean("pending", true);
        return s;
    }

    public void saveRoll(Context c) {
        sp(c).edit()
                .putString("layout", layout).putString("font", font).putString("theme", theme)
                .putString("tier", tier).putString("special", special)
                .putString("missingKeys", missingKeys).putString("features", features)
                .putInt("specialMask", specialMask).putInt("missingCount", missingCount)
                .putInt("rollCount", rollCount).putLong("seed", seed).putBoolean("pending", pending)
                .apply();
    }

    public void apply(Roller.Result r) {
        layout = r.layout;
        font = r.font;
        theme = r.theme;
        tier = r.tier;
        special = r.special;
        missingKeys = r.missingKeys;
        missingCount = r.missingCount;
        specialMask = r.specialMask;
        seed = r.seed;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < r.features.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append(r.features.get(i));
        }
        features = sb.toString();
    }

    public static void setPending(Context c, boolean v) {
        sp(c).edit().putBoolean("pending", v).apply();
    }

    public static void setChance(Context c, int v) {
        sp(c).edit().putInt("chance", v).apply();
    }

    public static Set<String> discovered(Context c) {
        return new HashSet<>(sp(c).getStringSet("disc", new HashSet<String>()));
    }

    public static void discover(Context c, Collection<String> keys) {
        Set<String> s = discovered(c);
        s.addAll(keys);
        sp(c).edit().putStringSet("disc", s).apply();
    }

    public static Set<String> discoverKeys(Roller.Result r) {
        Set<String> s = new HashSet<>();
        s.add("L:" + r.layout);
        s.add("F:" + r.font);
        s.add("T:" + r.theme);
        s.add("M:" + r.tier);
        s.add("S:" + r.special);
        for (String f : r.features) s.add("X:" + f);
        return s;
    }

    public static String discoverKey(String kind, String id) {
        return kind + ":" + id;
    }

    private void recomputeMissing(java.util.Random r) {
        String[] m = Roller.missing(Layouts.byId(layout), Missing.byId(Missing.TIERS, tier), r);
        missingKeys = m[0];
        missingCount = Integer.parseInt(m[1]);
    }

    /** Applies a single rolled item on top of the current setup. Returns a short description of the effect. */
    public String applyItem(Item it, java.util.Random r) {
        String kind = Roller.kindOf(it);
        String effect;
        switch (kind) {
            case "L":
                layout = it.id;
                seed = r.nextLong();
                recomputeMissing(r);
                effect = "New layout. Missing keys re-rolled for it (" + missingCount + " removed).";
                break;
            case "F":
                font = it.id;
                effect = "Everything you type now uses this font.";
                break;
            case "T":
                theme = it.id;
                effect = "New look.";
                break;
            case "M":
                tier = it.id;
                recomputeMissing(r);
                effect = missingCount + " letter keys removed from your current layout.";
                break;
            case "S":
                special = it.id;
                specialMask = ((MissingDef) it).mask;
                effect = specialMask == 0 ? "All special keys are back." : "Special keys changed.";
                break;
            default: {
                java.util.List<String> cur = new java.util.ArrayList<>();
                if (features != null && !features.isEmpty()) cur.addAll(java.util.Arrays.asList(features.split(",")));
                if (cur.contains(it.id)) {
                    cur.remove(it.id);
                    effect = "Feature was ON, so it is now switched OFF.";
                } else {
                    if (it.group != null) {
                        java.util.Iterator<String> iter = cur.iterator();
                        while (iter.hasNext()) {
                            Item o = Features.byId(iter.next());
                            if (o != null && it.group.equals(o.group)) iter.remove();
                        }
                    }
                    cur.add(it.id);
                    effect = "Feature switched ON.";
                }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < cur.size(); i++) {
                    if (i > 0) sb.append(',');
                    sb.append(cur.get(i));
                }
                features = sb.toString();
            }
        }
        rollCount++;
        pending = false;
        return effect;
    }
}
