package com.rollkeyboard;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private TextView status, chanceLabel, catalog;
    private boolean catalogOn;

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(6), 0, dp(6));
        return t;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18), dp(24), dp(18), dp(24));
        sv.addView(col, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("🎲 Roll Keyboard", 28f, 0xFFFFFFFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(title);
        col.addView(text("A keyboard that forces you to roll for your layout, font, missing keys and features. "
                + "Every roll is permanent until the next roll.", 14f, 0xFFBBBBCC));

        Button enable = new Button(this);
        enable.setText("1. Enable the keyboard");
        enable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        });
        col.addView(enable);

        Button select = new Button(this);
        select.setText("2. Select the keyboard");
        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        });
        col.addView(select);

        EditText test = new EditText(this);
        test.setHint("Tap here to test your keyboard");
        col.addView(test);

        col.addView(text("CURRENT ROLL", 12f, 0xFF8888AA));
        status = text("", 14f, 0xFFFFFFFF);
        col.addView(status);

        col.addView(text("ROLL CHANCE", 12f, 0xFF8888AA));
        chanceLabel = text("", 14f, 0xFFFFFFFF);
        col.addView(chanceLabel);
        SeekBar bar = new SeekBar(this);
        bar.setMax(100);
        bar.setProgress(RollState.load(this).chance);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                chanceLabel.setText("Chance of a forced roll each time the keyboard opens: " + p + "%\n"
                        + "(the first time you switch to it always rolls)");
                if (user) RollState.setChance(MainActivity.this, p);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        col.addView(bar);
        chanceLabel.setText("Chance of a forced roll each time the keyboard opens: " + bar.getProgress() + "%\n"
                + "(the first time you switch to it always rolls)");

        Button cat = new Button(this);
        cat.setText("Show / hide the full catalog");
        cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                catalogOn = !catalogOn;
                refresh();
            }
        });
        col.addView(cat);
        catalog = text("", 13f, 0xFFDDDDDD);
        col.addView(catalog);

        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private SpannableStringBuilder line(SpannableStringBuilder sb, String s, int color) {
        int a = sb.length();
        sb.append(s);
        sb.setSpan(new ForegroundColorSpan(color), a, sb.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sb;
    }

    private void refresh() {
        RollState s = RollState.load(this);
        Set<String> disc = RollState.discovered(this);
        LayoutDef l = Layouts.byId(s.layout);
        FontDef f = Fonts.byId(s.font);
        ThemeDef t = Themes.byId(s.theme);
        MissingDef tier = Missing.byId(Missing.TIERS, s.tier);
        MissingDef sp = Missing.byId(Missing.SPECIALS, s.special);
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (s.rollCount == 0) {
            line(sb, "No rolls yet. Switch to the keyboard and roll!", 0xFFFFFFFF);
        } else {
            line(sb, "Rolls so far: " + s.rollCount + "\n", 0xFFFFFFFF);
            line(sb, "Layout: " + l.name + " [" + l.rarity.label + "]\n", l.rarity.color);
            line(sb, "Font: " + f.name + " [" + f.rarity.label + "]\n", f.rarity.color);
            line(sb, "Missing: " + tier.name + " (" + s.missingCount + " removed)\n", tier.rarity.color);
            line(sb, "Specials: " + sp.name + "\n", sp.rarity.color);
            line(sb, "Theme: " + t.name + " [" + t.rarity.label + "]\n", t.rarity.color);
            if (s.features == null || s.features.isEmpty()) {
                line(sb, "Features: none", 0xFFB0B0B0);
            } else {
                for (String id : s.features.split(",")) {
                    Item it = Features.byId(id);
                    if (it != null) line(sb, "• " + it.name + "\n", it.rarity.color);
                }
            }
        }
        status.setText(sb);

        int total = Layouts.ALL.size() + Fonts.ALL.size() + Features.ALL.size() + Themes.ALL.size()
                + Missing.TIERS.size() + Missing.SPECIALS.size();
        if (!catalogOn) {
            catalog.setText("Collection: " + disc.size() + " / " + total + " discovered");
            return;
        }
        SpannableStringBuilder c = new SpannableStringBuilder();
        line(c, "Collection: " + disc.size() + " / " + total + " discovered\n\n", 0xFFFFFFFF);
        section(c, "LAYOUTS", "L:", new ArrayList<Item>(Layouts.ALL), disc);
        section(c, "FONTS", "F:", new ArrayList<Item>(Fonts.ALL), disc);
        section(c, "FEATURES", "X:", new ArrayList<Item>(Features.ALL), disc);
        section(c, "THEMES", "T:", new ArrayList<Item>(Themes.ALL), disc);
        section(c, "MISSING KEY TIERS", "M:", new ArrayList<Item>(Missing.TIERS), disc);
        section(c, "SPECIAL KEY LOSSES", "S:", new ArrayList<Item>(Missing.SPECIALS), disc);
        catalog.setText(c);
    }

    private void section(SpannableStringBuilder sb, String title, String prefix, List<Item> list, Set<String> disc) {
        Collections.sort(list, new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                if (a.rarity != b.rarity) return a.rarity.ordinal() - b.rarity.ordinal();
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        int found = 0;
        for (Item i : list) if (disc.contains(prefix + i.id)) found++;
        line(sb, "== " + title + " (" + found + "/" + list.size() + ") ==\n", 0xFFFFFFFF);
        Rarity last = null;
        for (Item i : list) {
            if (i.rarity != last) {
                last = i.rarity;
                line(sb, "-- " + last.label + " --\n", last.color);
            }
            boolean d = disc.contains(prefix + i.id);
            line(sb, (d ? "★ " : "· ") + i.name + "\n", d ? i.rarity.color : 0xFF777788);
        }
        sb.append("\n");
    }
}
