package com.rollkeyboard;

public class ThemeDef extends Item {
    public final int bg, key, text, mod;

    public ThemeDef(String id, String name, Rarity r, int bg, int key, int text, int mod) {
        super(id, name, r, null);
        this.bg = bg;
        this.key = key;
        this.text = text;
        this.mod = mod;
    }
}
