package com.rollkeyboard;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

public class RollKeyboardService extends InputMethodService {

    private static final String[][] SYM1 = {
            {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"},
            {"@", "#", "$", "_", "&", "-", "+", "(", ")", "/"},
            {"*", "\"", "'", ":", ";", "!", "?", ",", "."}};
    private static final String[][] SYM2 = {
            {"~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆"},
            {"£", "€", "¥", "^", "°", "=", "{", "}", "\\", "%"},
            {"©", "®", "™", "✓", "[", "]", "<", ">", "¡", "¿"}};
    private static final String WHEEL = "abcdefghijklmnopqrstuvwxyz0123456789.,!?'-";

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private float density = 3f;

    private RollState st = new RollState();
    private LayoutDef layout;
    private FontDef font;
    private ThemeDef theme;
    private final Set<String> feats = new HashSet<>();
    private final List<List<String>> rows = new ArrayList<>();
    private final List<List<String>> liar = new ArrayList<>();

    private FrameLayout root;
    private LinearLayout kbRoot, rollOverlay;
    private TextView preview, counterView;
    private TextView[] sugViews;

    private boolean shift, caps, overlayActive, rolled;
    private int page;
    private long lastShiftTap, lastTap, pendingTime, t9Time;
    private String pendingTap, t9Last;
    private int t9Idx, lastOutCp, wheelIdx, keystrokes;
    private boolean altCase;
    private final StringBuilder buf = new StringBuilder();
    private Runnable activeRep;
    private ToneGenerator tone;
    private final Set<String> dead = new HashSet<>();
    private long lastMeme;

    private int gapPx, radPx;

    // roll screen state
    private TextView rollTitle, rollBtn;
    private TextView[] slotVal;
    private boolean[] revealed;
    private long spinStart;
    private Roller.Result lastRes;
    private LayoutDef curLayout;
    private FontDef curFont;
    private ThemeDef curTheme;
    private MissingDef curTier, curSpecial;
    private final List<Item> curFeatures = new ArrayList<>();

    // ------------------------------------------------------------ lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        density = getResources().getDisplayMetrics().density;
        RollState.setPending(this, true); // first time switching to it forces a roll
        loadConfig();
    }

    @Override
    public View onCreateInputView() {
        root = new FrameLayout(this);
        kbRoot = new LinearLayout(this);
        kbRoot.setOrientation(LinearLayout.VERTICAL);
        rollOverlay = new LinearLayout(this);
        rollOverlay.setOrientation(LinearLayout.VERTICAL);
        root.addView(kbRoot, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(rollOverlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(340)));
        rollOverlay.setVisibility(View.GONE);
        overlayActive = false;
        rebuildKeyboard();
        return root;
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        if (root == null) return;
        if (overlayActive) return;
        RollState s = RollState.load(this);
        if (!restarting) {
            boolean force = s.pending || s.rollCount == 0 || rnd.nextInt(100) < s.chance;
            if (force) {
                showRollScreen();
                return;
            }
        }
        buf.setLength(0);
        loadConfig();
        rebuildKeyboard();
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        super.onFinishInputView(finishingInput);
        cancelRepeat();
    }

    @Override
    public void onDestroy() {
        cancelRepeat();
        h.removeCallbacksAndMessages(null);
        if (tone != null) {
            try {
                tone.release();
            } catch (Exception ignored) {
            }
            tone = null;
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------ config

    private boolean has(String id) {
        return feats.contains(id);
    }

    private int dp(int v) {
        return Math.round(v * density);
    }

    private void loadConfig() {
        st = RollState.load(this);
        dead.clear();
        layout = Layouts.byId(st.layout);
        font = Fonts.byId(st.font);
        theme = Themes.byId(st.theme);
        feats.clear();
        if (st.features != null && !st.features.isEmpty()) feats.addAll(Arrays.asList(st.features.split(",")));
        buildRows();
    }

    private void buildRows() {
        rows.clear();
        liar.clear();
        String[][] base = layout.rows;
        String[][] src = new String[base.length][];
        for (int i = 0; i < base.length; i++) src[i] = base[i].clone();
        if (layout.scramble) {
            List<String> all = new ArrayList<>();
            for (String[] r : src) all.addAll(Arrays.asList(r));
            long sd = layout.id.equals("fresh_scramble") ? System.nanoTime() : st.seed;
            Collections.shuffle(all, new Random(sd));
            int p = 0;
            for (String[] r : src) for (int c = 0; c < r.length; c++) r[c] = all.get(p++);
        }
        Set<String> missing = new HashSet<>();
        if (st.missingKeys != null && !st.missingKeys.isEmpty())
            missing.addAll(Arrays.asList(st.missingKeys.split(";")));
        for (int r = 0; r < src.length; r++) {
            List<String> row = new ArrayList<>();
            for (int c = 0; c < src[r].length; c++) if (!missing.contains(r + ":" + c)) row.add(src[r][c]);
            if (!row.isEmpty()) rows.add(row);
        }
        // liar labels: shuffled copy of all tokens
        List<String> flat = new ArrayList<>();
        for (List<String> r : rows) flat.addAll(r);
        List<String> sh = new ArrayList<>(flat);
        Collections.shuffle(sh, new Random(st.seed + 7));
        int p = 0;
        for (List<String> r : rows) {
            List<String> lr = new ArrayList<>();
            for (int i = 0; i < r.size(); i++) lr.add(sh.get(p++));
            liar.add(lr);
        }
    }

    private void shuffleRows() {
        List<String> flat = new ArrayList<>();
        for (List<String> r : rows) flat.addAll(r);
        Collections.shuffle(flat, rnd);
        int p = 0;
        for (List<String> r : rows) for (int i = 0; i < r.size(); i++) r.set(i, flat.get(p++));
    }

    // ------------------------------------------------------------ keyboard UI

    private void cancelRepeat() {
        if (activeRep != null) {
            h.removeCallbacks(activeRep);
            activeRep = null;
        }
    }

    private boolean upperNow() {
        if (has("caps_lock")) return true;
        if (has("lower_only")) return false;
        boolean s = shift || caps;
        return has("inverted_shift") ? !s : s;
    }

    private void rebuildKeyboard() {
        if (kbRoot == null) return;
        cancelRepeat();
        overlayActive = false;
        rollOverlay.setVisibility(View.GONE);
        kbRoot.setVisibility(View.VISIBLE);
        kbRoot.removeAllViews();
        preview = null;
        counterView = null;
        sugViews = null;
        kbRoot.setBackgroundColor(theme.bg);
        kbRoot.setRotation(0f);
        kbRoot.setScaleX(1f);
        kbRoot.setScaleY(1f);
        kbRoot.setTranslationX(0f);
        kbRoot.setTranslationY(0f);
        if (has("upside_down")) kbRoot.setRotation(180f);
        if (has("mirrored_kb")) kbRoot.setScaleX(-1f);
        if (has("tilted_kb")) {
            kbRoot.setRotation(kbRoot.getRotation() + 5f);
            kbRoot.setScaleX(kbRoot.getScaleX() * 0.95f);
            kbRoot.setScaleY(0.95f);
        }

        gapPx = has("gapless") ? 0 : (has("chunky_gaps") ? dp(7) : dp(3));
        radPx = has("sharp_keys") || has("gapless") ? 0 : (has("pill_keys") ? dp(40) : dp(8));

        int keysH = dp(has("tiny_kb") ? 190 : has("tall_kb") ? 320 : has("huge_kb") ? 380 : has("flat_kb") ? 200 : 260);
        if ((st.specialMask & Missing.SYM) != 0) page = 0;
        boolean sym = page != 0;
        int rc = 1 + (sym ? 3 : rows.size());
        if (has("number_row") && !sym) rc++;
        if (has("emoji_row")) rc++;
        if (has("edit_bar")) rc++;
        if (has("cursor_keys")) rc++;
        int rowH = Math.max(dp(has("tiny_kb") ? 30 : 38), keysH / rc);

        kbRoot.addView(buildToolbar(), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)));

        if (layout.bufferMode()) {
            preview = new TextView(this);
            preview.setGravity(Gravity.CENTER);
            preview.setTextColor(theme.text);
            preview.setTextSize(15f);
            preview.setBackgroundColor(theme.mod);
            kbRoot.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));
            updatePreview();
        }
        if (has("suggestions")) addSuggestionBar();

        if (has("emoji_row")) addEmojiRow(rowH);
        if (has("edit_bar")) addEditBar(rowH);
        if (has("cursor_keys")) addCursorRow(rowH);
        if (has("number_row") && !sym) {
            LinearLayout nr = newRow(rowH);
            for (int d = 1; d <= 10; d++) {
                final String dg = String.valueOf(d % 10);
                addKey(nr, dg, 1f, keyBg(), theme.text, 18f, new Runnable() {
                    @Override
                    public void run() {
                        guard("N" + dg, new Runnable() {
                            @Override
                            public void run() {
                                emitText(dg, true);
                            }
                        });
                    }
                }, has("turbo_repeat"));
            }
        }

        if (sym) {
            String[][] src = page == 1 ? SYM1 : SYM2;
            for (String[] sr : src) {
                LinearLayout row = newRow(rowH);
                for (final String tok : sr) {
                    addKey(row, tok, 1f, keyBg(), theme.text, 20f, new Runnable() {
                        @Override
                        public void run() {
                            guard("S" + tok, new Runnable() {
                                @Override
                                public void run() {
                                    emitText(tok, true);
                                }
                            });
                        }
                    }, has("turbo_repeat"));
                }
            }
        } else {
            int maxKeys = 1;
            for (List<String> r : rows) maxKeys = Math.max(maxKeys, r.size());
            float textSp = textSizeFor();
            for (int r = 0; r < rows.size(); r++) {
                LinearLayout row = newRow(rowH);
                List<String> rw = rows.get(r);
                float pad = (maxKeys - rw.size()) / 2f;
                if (pad > 0) addSpacer(row, pad);
                for (int c = 0; c < rw.size(); c++) {
                    final int rr = r, cc = c;
                    final String tok = rw.get(c);
                    if (dead.contains(rr + ":" + cc)) {
                        addSpacer(row, 1f);
                        continue;
                    }
                    addKey(row, labelFor(r, c, tok), 1f, keyBg(), theme.text, textSp, new Runnable() {
                        @Override
                        public void run() {
                            guard("L" + rr + ":" + cc, new Runnable() {
                                @Override
                                public void run() {
                                    letterAct(rr, cc, tok);
                                }
                            });
                        }
                    }, has("turbo_repeat"));
                }
                if (pad > 0) addSpacer(row, pad);
            }
        }
        addBottomRow(rowH);
    }

    private void addSpacer(LinearLayout row, float weight) {
        View v = new View(this);
        row.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight));
    }

    private LinearLayout newRow(int rowH) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        kbRoot.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rowH));
        return row;
    }

    private int keyBg() {
        if (has("rainbow_keys") || has("strobe_keys")) {
            return Color.HSVToColor(new float[]{rnd.nextFloat() * 360f, 0.55f, 0.95f});
        }
        return theme.key;
    }

    private int keyFg(int bg) {
        if (has("rainbow_keys") || has("strobe_keys")) return 0xFF111111;
        return theme.text;
    }

    private float textSizeFor() {
        int maxKeys = 1, maxLen = 1;
        for (List<String> rw : rows) {
            maxKeys = Math.max(maxKeys, rw.size());
            for (String t : rw) maxLen = Math.max(maxLen, t.codePointCount(0, t.length()));
        }
        float byCount = maxKeys <= 4 ? 30 : maxKeys <= 7 ? 24 : maxKeys <= 10 ? 20 : maxKeys <= 12 ? 17
                : maxKeys <= 15 ? 14 : maxKeys <= 20 ? 12 : 10;
        float byLen = maxLen <= 1 ? 99 : maxLen <= 2 ? 22 : maxLen <= 3 ? 17
                : maxLen <= 5 ? (maxKeys <= 5 ? 16 : 12) : maxLen <= 8 ? (maxKeys <= 4 ? 14 : 10) : 9;
        return Math.min(byCount, byLen);
    }

    private String labelFor(int r, int c, String tok) {
        if (has("blind_keys")) return "";
        String t = tok;
        if (has("liar_labels") && r < liar.size() && c < liar.get(r).size()) t = liar.get(r).get(c);
        switch (t) {
            case "§R": return "🎲";
            case "§V": return "🅰";
            case "§C": return "🅱";
            case "§W": return "📖";
            case "§E": return "😀";
            default:
        }
        if (layout.mode == Layouts.M_NORMAL || layout.mode == Layouts.M_WORDS || layout.mode == Layouts.M_T9) {
            return upperNow() ? t.toUpperCase(Locale.ROOT) : t;
        }
        return t;
    }

    private TextView addKey(LinearLayout row, String label, float weight, int bg, int fg, float sp,
                            final Runnable action, final boolean repeat) {
        final TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(has("rainbow_keys") || has("strobe_keys") ? 0xFF111111 : fg);
        tv.setTextSize(sp);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(bg);
        gd.setCornerRadius(radPx);
        if (gapPx == 0) gd.setStroke(1, theme.bg);
        tv.setBackground(gd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(gapPx, gapPx, gapPx, gapPx);
        row.addView(tv, lp);
        if (has("drunk_keys")) {
            tv.setRotation((rnd.nextFloat() - 0.5f) * 18f);
            tv.setTranslationY((rnd.nextFloat() - 0.5f) * dp(6));
        }
        tv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        tv.setAlpha(0.6f);
                        feedback(tv);
                        action.run();
                        if (repeat && kbRoot != null && tv.isAttachedToWindow()) {
                            cancelRepeat();
                            activeRep = new Runnable() {
                                @Override
                                public void run() {
                                    if (activeRep != this) return;
                                    action.run();
                                    if (activeRep == this) h.postDelayed(this, 55);
                                }
                            };
                            h.postDelayed(activeRep, 420);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        tv.setAlpha(1f);
                        cancelRepeat();
                        return true;
                    default:
                        return true;
                }
            }
        });
        return tv;
    }

    private View buildToolbar() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.HORIZONTAL);
        t.setBackgroundColor(0xFF101014);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.addView(toolBtn("🌐", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        }), new LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT));
        t.addView(toolBtn("🎲", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRollScreen();
            }
        }), new LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT));
        TextView info = new TextView(this);
        info.setText(layout.rarity.label.toUpperCase(Locale.ROOT) + " · " + layout.name);
        info.setTextColor(layout.rarity.color);
        info.setTextSize(11f);
        info.setSingleLine(true);
        info.setEllipsize(TextUtils.TruncateAt.END);
        info.setGravity(Gravity.CENTER_VERTICAL);
        t.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        if (has("keystroke_counter")) {
            counterView = new TextView(this);
            counterView.setText("⌨ " + keystrokes);
            counterView.setTextColor(0xFFCCCCCC);
            counterView.setTextSize(12f);
            counterView.setGravity(Gravity.CENTER);
            counterView.setPadding(dp(8), 0, dp(8), 0);
            t.addView(counterView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }
        return t;
    }

    private TextView toolBtn(String s, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(s);
        b.setTextSize(18f);
        b.setTextColor(0xFFFFFFFF);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(l);
        return b;
    }

    private void addSuggestionBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(theme.mod);
        sugViews = new TextView[3];
        for (int i = 0; i < 3; i++) {
            final TextView t = new TextView(this);
            t.setGravity(Gravity.CENTER);
            t.setTextColor(theme.text);
            t.setTextSize(15f);
            t.setSingleLine(true);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    commit(font.apply(t.getText().toString()) + " ");
                    afterPress();
                }
            });
            sugViews[i] = t;
            bar.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }
        kbRoot.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
        updateSuggestions();
    }

    private void updateSuggestions() {
        if (sugViews == null) return;
        for (TextView t : sugViews) t.setText(Words.SUGGEST[rnd.nextInt(Words.SUGGEST.length)]);
    }

    private void addEmojiRow(int rowH) {
        LinearLayout row = newRow(rowH);
        for (int i = 0; i < 9; i++) {
            final String e = Words.EMOJIS[rnd.nextInt(Words.EMOJIS.length)];
            addKey(row, e, 1f, keyBg(), theme.text, 20f, new Runnable() {
                @Override
                public void run() {
                    commit(e);
                    afterPress();
                }
            }, false);
        }
    }

    private void addCursorRow(int rowH) {
        LinearLayout row = newRow(rowH);
        String[] lab = {"⇱", "◀", "▲", "▼", "▶", "⇲"};
        final int[] code = {KeyEvent.KEYCODE_MOVE_HOME, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MOVE_END};
        for (int i = 0; i < lab.length; i++) {
            final int k = code[i];
            addKey(row, lab[i], 1f, theme.mod, theme.text, 18f, new Runnable() {
                @Override
                public void run() {
                    sendDownUpKeyEvents(k);
                }
            }, true);
        }
    }

    private void addEditBar(int rowH) {
        LinearLayout row = newRow(rowH);
        String[] lab = {"Select all", "Copy", "Cut", "Paste"};
        final int[] ids = {android.R.id.selectAll, android.R.id.copy, android.R.id.cut, android.R.id.paste};
        for (int i = 0; i < lab.length; i++) {
            final int id = ids[i];
            addKey(row, lab[i], 1f, theme.mod, theme.text, 12f, new Runnable() {
                @Override
                public void run() {
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) ic.performContextMenuAction(id);
                }
            }, false);
        }
    }

    private void addBottomRow(int rowH) {
        LinearLayout br = newRow(rowH);
        int mask = st.specialMask;
        if ((mask & Missing.SYM) == 0) {
            addKey(br, page == 0 ? "?123" : (page == 1 ? "~{[" : "ABC"), 1.4f, theme.mod, theme.text, 13f, new Runnable() {
                @Override
                public void run() {
                    page = (page + 1) % 3;
                    dead.clear();
                    rebuildKeyboard();
                }
            }, false);
        } else if (page != 0) {
            page = 0;
        }
        if ((mask & Missing.SHIFT) == 0 && !has("caps_lock") && !has("lower_only") && page == 0) {
            addKey(br, caps ? "⇪" : (shift ? "⬆" : "⇧"), 1.2f, theme.mod, theme.text, 18f, new Runnable() {
                @Override
                public void run() {
                    shiftAct();
                }
            }, false);
        }
        if (has("paste_key")) {
            addKey(br, "📋", 1.1f, theme.mod, theme.text, 16f, new Runnable() {
                @Override
                public void run() {
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) ic.performContextMenuAction(android.R.id.paste);
                }
            }, false);
        }
        if ((mask & Missing.SPACE) == 0) {
            addKey(br, "space", 4f, keyBg(), theme.text, 12f, new Runnable() {
                @Override
                public void run() {
                    guard("SPACE", new Runnable() {
                        @Override
                        public void run() {
                            spaceAct();
                        }
                    });
                }
            }, has("turbo_repeat"));
        }
        if ((mask & Missing.BKSP) == 0) {
            addKey(br, "⌫", 1.4f, theme.mod, theme.text, 18f, new Runnable() {
                @Override
                public void run() {
                    guard("BKSP", new Runnable() {
                        @Override
                        public void run() {
                            backspaceAct();
                        }
                    });
                }
            }, true);
        }
        if ((mask & Missing.ENTER) == 0) {
            addKey(br, "⏎", 1.4f, theme.mod, theme.text, 18f, new Runnable() {
                @Override
                public void run() {
                    guard("ENTER", new Runnable() {
                        @Override
                        public void run() {
                            enterAct();
                        }
                    });
                }
            }, false);
        }
    }

    private void updatePreview() {
        if (preview == null) return;
        String s = "";
        switch (layout.mode) {
            case Layouts.M_MORSE: {
                String d = Words.MORSE_REV.get(buf.toString());
                s = (buf.length() == 0 ? "(tap • and —, then ✓)" : buf.toString()) + (d != null ? "  →  " + d : "");
                break;
            }
            case Layouts.M_BIN:
                s = buf + "   (" + (8 - buf.length()) + " bits left)";
                break;
            case Layouts.M_HEX:
                s = buf + "   (" + (2 - buf.length()) + " digits left)";
                break;
            case Layouts.M_DEC:
            case Layouts.M_UNI:
                s = buf.length() == 0 ? "(type a code, then ✓)" : buf.toString();
                break;
            case Layouts.M_WHEEL:
                s = "‹  " + WHEEL.charAt(wheelIdx) + "  ›";
                break;
            default:
        }
        preview.setText(s);
    }

    // ------------------------------------------------------------ feedback

    private void feedback(View v) {
        if (has("haptics_strong")) v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        else if (!has("haptics_off")) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        if (has("click_sound")) {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am != null) am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD);
        }
        if (has("beep_orchestra")) {
            try {
                if (tone == null) tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 60);
                tone.startTone(rnd.nextInt(16), 90);
            } catch (Exception ignored) {
            }
        }
    }

    // ------------------------------------------------------------ gating

    private void guard(String keyId, final Runnable act) {
        long now = SystemClock.uptimeMillis();
        if (has("cooldown") && now - lastTap < 350) return;
        if (has("ghost_press") && rnd.nextInt(100) < 7) return;
        if (has("double_tap")) {
            if (!(keyId.equals(pendingTap) && now - pendingTime < 1500)) {
                pendingTap = keyId;
                pendingTime = now;
                return;
            }
            pendingTap = null;
        }
        lastTap = now;
        if (has("laggy")) h.postDelayed(act, 600);
        else act.run();
    }

    // ------------------------------------------------------------ key actions

    private boolean isReverse() {
        return font.reverseInsert || has("reverse_typing");
    }

    private void commit(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || s == null || s.isEmpty()) return;
        ic.commitText(s, isReverse() ? 0 : 1);
        lastOutCp = s.codePointCount(0, s.length());
    }

    private boolean wantAutoShift() {
        if (!has("auto_cap")) return false;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return false;
        CharSequence b = ic.getTextBeforeCursor(3, 0);
        if (b == null || b.length() == 0) return true;
        String s = b.toString();
        if (s.endsWith("\n")) return true;
        int n = s.length();
        return n >= 2 && s.charAt(n - 1) == ' ' && ".!?".indexOf(s.charAt(n - 2)) >= 0;
    }

    private void afterPress() {
        keystrokes++;
        if (counterView != null) counterView.setText("⌨ " + keystrokes);
        boolean rebuild = false;
        if (!caps) {
            boolean ns = wantAutoShift();
            if (ns != shift) {
                shift = ns;
                rebuild = true;
            }
        }
        if (has("shuffle_after")) {
            shuffleRows();
            rebuild = true;
        }
        if (has("strobe_keys") || has("hot_potato")) rebuild = true;
        if (has("suggestions")) updateSuggestions();
        if (devilishTick()) rebuild = true;
        if (has("chaos_mode") && rnd.nextInt(100) < 2) {
            showRollScreen();
            return;
        }
        if (rebuild) rebuildKeyboard();
        if (has("earthquake_kb") && kbRoot != null) {
            kbRoot.setTranslationX((rnd.nextFloat() - 0.5f) * dp(44));
            kbRoot.setTranslationY((rnd.nextFloat() - 0.5f) * dp(18));
        }
    }

    /** Runs the Devilish prank features. Returns true if the keyboard must be rebuilt. */
    private boolean devilishTick() {
        boolean rebuild = false;
        InputConnection ic = getCurrentInputConnection();
        long now = SystemClock.uptimeMillis();
        if (has("meme_videos") && now - lastMeme > 15000 && rnd.nextInt(100) < 4) {
            lastMeme = now;
            openMeme();
        }
        if (ic != null) {
            if (has("cursor_teleport") && rnd.nextInt(100) < 3) sendDownUpKeyEvents(KeyEvent.KEYCODE_MOVE_HOME);
            if (has("gremlin_eraser") && rnd.nextInt(100) < 3) ic.deleteSurroundingText(1 + rnd.nextInt(3), 0);
            if (has("paste_poltergeist") && rnd.nextInt(100) < 3) ic.performContextMenuAction(android.R.id.paste);
            if (has("phantom_enter") && rnd.nextInt(100) < 3) ic.commitText("\n", 1);
        }
        if (has("caps_storm") && rnd.nextInt(100) < 6) {
            caps = !caps;
            rebuild = true;
        }
        if (has("swap_party") && keystrokes % 5 == 0 && !rows.isEmpty()) {
            int r1 = rnd.nextInt(rows.size()), r2 = rnd.nextInt(rows.size());
            int c1 = rnd.nextInt(rows.get(r1).size()), c2 = rnd.nextInt(rows.get(r2).size());
            String tmp = rows.get(r1).get(c1);
            rows.get(r1).set(c1, rows.get(r2).get(c2));
            rows.get(r2).set(c2, tmp);
            rebuild = true;
        }
        if (has("haptic_quake") && rnd.nextInt(100) < 12) buzz();
        if (has("alarm_gremlin") && rnd.nextInt(100) < 4) alarmBeep();
        return rebuild;
    }

    private void openMeme() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(Words.MEMES[rnd.nextInt(Words.MEMES.length)]));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    @SuppressWarnings("deprecation")
    private void buzz() {
        try {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(350);
            }
        } catch (Exception ignored) {
        }
    }

    private void alarmBeep() {
        try {
            final ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
            tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500);
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        tg.release();
                    } catch (Exception ignored) {
                    }
                }
            }, 1200);
        } catch (Exception ignored) {
        }
    }

    private void letterAct(int r, int c, String tok) {
        String t = tok;
        if (has("hot_potato")) dead.add(r + ":" + c);
        if ((layout.mode == Layouts.M_NORMAL || layout.mode == Layouts.M_WORDS) && r < rows.size()) {
            t = driftToken(r, c, t);
        }
        switch (layout.mode) {
            case Layouts.M_T9:
                t9Key(t);
                break;
            case Layouts.M_MORSE:
            case Layouts.M_BIN:
            case Layouts.M_HEX:
            case Layouts.M_DEC:
            case Layouts.M_UNI:
            case Layouts.M_WHEEL:
                bufferKey(t);
                break;
            default:
                emitText(t, false);
        }
    }

    private String driftToken(int r, int c, String t) {
        List<String> rw = rows.get(r);
        if (c >= rw.size()) return t;
        if (has("mirror_hand")) return rw.get(rw.size() - 1 - c);
        if (has("neighbor_drift") && rnd.nextInt(100) < 8 && rw.size() > 1) {
            int n = c + (rnd.nextBoolean() ? 1 : -1);
            if (n < 0) n = 1;
            if (n >= rw.size()) n = rw.size() - 2;
            return rw.get(n);
        }
        return t;
    }

    private String resolveRandom(String t) {
        switch (t) {
            case "§R": return String.valueOf((char) ('a' + rnd.nextInt(26)));
            case "§V": return String.valueOf("aeiou".charAt(rnd.nextInt(5)));
            case "§C": return String.valueOf("bcdfghjklmnpqrstvwxyz".charAt(rnd.nextInt(21)));
            case "§W": return Words.SILLY[rnd.nextInt(Words.SILLY.length)] + " ";
            case "§E": return Words.EMOJIS[rnd.nextInt(Words.EMOJIS.length)];
            default: return t;
        }
    }

    private String charPipeline(String s) {
        boolean any = has("vowel_cycle") || has("vowel_ghost") || has("vowel_star") || has("caesar1")
                || has("atbash") || has("rot13") || has("uwu");
        if (!any) return s;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            boolean up = c >= 'A' && c <= 'Z';
            char lc = up ? (char) (c + 32) : c;
            boolean letter = lc >= 'a' && lc <= 'z';
            if (!letter) {
                sb.append(c);
                continue;
            }
            String out = String.valueOf(lc);
            if (has("uwu") && (lc == 'r' || lc == 'l')) out = "w";
            if (has("vowel_cycle")) {
                int v = "aeiou".indexOf(lc);
                if (v >= 0) out = String.valueOf("eioua".charAt(v));
            } else if (has("vowel_ghost")) {
                if ("aeiou".indexOf(lc) >= 0) out = "";
            } else if (has("vowel_star")) {
                if ("aeiou".indexOf(lc) >= 0) out = "*";
            }
            if (out.length() == 1 && out.charAt(0) >= 'a' && out.charAt(0) <= 'z') {
                char o = out.charAt(0);
                if (has("caesar1")) o = (char) ('a' + (o - 'a' + 1) % 26);
                else if (has("atbash")) o = (char) ('z' - (o - 'a'));
                else if (has("rot13")) o = (char) ('a' + (o - 'a' + 13) % 26);
                out = String.valueOf(o);
            }
            sb.append(up ? out.toUpperCase(Locale.ROOT) : out);
        }
        return sb.toString();
    }

    private String punct(String t) {
        if (t.equals(".")) {
            if (has("uptalk")) t = "?";
            else if (has("exclaim")) t = "!";
        }
        if (t.equals(".") && has("dots_spam")) return "...";
        if (t.equals("!") && has("bang_spam")) return "!!!";
        if (t.equals("?") && has("question_inv")) return "¿?";
        return t;
    }

    private String caseify(String s) {
        if (has("spongebob")) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (Character.isLetter(c)) {
                    sb.append(altCase ? Character.toUpperCase(c) : Character.toLowerCase(c));
                    altCase = !altCase;
                } else sb.append(c);
            }
            return sb.toString();
        }
        if (has("random_case")) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                sb.append(Character.isLetter(c) ? (rnd.nextBoolean() ? Character.toUpperCase(c) : Character.toLowerCase(c)) : c);
            }
            return sb.toString();
        }
        return upperNow() ? s.toUpperCase(Locale.ROOT) : s.toLowerCase(Locale.ROOT);
    }

    private String process(String token) {
        String t = resolveRandom(token);
        if (has("emoji_hijack") && rnd.nextInt(100) < 6) return Words.EMOJIS[rnd.nextInt(Words.EMOJIS.length)];
        t = charPipeline(t);
        if (t.isEmpty()) return "";
        t = punct(t);
        if (has("numbers_words") && t.length() == 1 && t.charAt(0) >= '0' && t.charAt(0) <= '9') {
            t = Words.NUM_WORDS[t.charAt(0) - '0'] + " ";
        } else {
            t = caseify(t);
        }
        if (has("triple_letters")) t = t + t + t;
        else if (has("double_letters")) t = t + t;
        else if (has("stuck_keys") && rnd.nextInt(100) < 10) t = t + t + t;
        t = font.apply(t);
        if (layout.mode == Layouts.M_WORDS && !token.startsWith("§")) t += " ";
        return t;
    }

    private void emitText(String token, boolean sym) {
        String out = process(token);
        if (out != null && !out.isEmpty()) {
            commit(out);
            postCommit(out);
        }
        afterPress();
    }

    private void postCommit(String out) {
        if (has("typo_swap") && !isReverse() && out.length() == 1 && Character.isLetter(out.charAt(0))
                && rnd.nextInt(100) < 10) {
            InputConnection ic = getCurrentInputConnection();
            if (ic == null) return;
            CharSequence b = ic.getTextBeforeCursor(2, 0);
            if (b != null && b.length() == 2 && Character.isLetter(b.charAt(0)) && Character.isLetter(b.charAt(1))) {
                ic.deleteSurroundingText(2, 0);
                ic.commitText("" + b.charAt(1) + b.charAt(0), 1);
            }
        }
    }

    // ---- T9

    private void t9Key(String token) {
        long now = SystemClock.uptimeMillis();
        int cpCount = token.codePointCount(0, token.length());
        boolean cycle = token.equals(t9Last) && now - t9Time < 900;
        t9Idx = cycle ? (t9Idx + 1) % cpCount : 0;
        String ch = new String(Character.toChars(token.codePointAt(token.offsetByCodePoints(0, t9Idx))));
        t9Last = token;
        t9Time = now;
        InputConnection ic = getCurrentInputConnection();
        if (cycle && ic != null && lastOutCp > 0) ic.deleteSurroundingText(lastOutCp, 0);
        String out = process(ch);
        if (out != null && !out.isEmpty()) commit(out);
        else lastOutCp = 0;
        afterPress();
    }

    // ---- buffer modes (morse / binary / hex / decimal / unicode / wheel)

    private void emitCodePoint(int v) {
        if (v == 10 || (v >= 32 && v != 127 && v <= 0x10FFFF && !(v >= 0xD800 && v <= 0xDFFF))) {
            emitText(new String(Character.toChars(v)), true);
        } else {
            afterPress();
        }
    }

    private void bufferKey(String token) {
        switch (layout.mode) {
            case Layouts.M_MORSE:
                if (token.equals("•")) buf.append('.');
                else if (token.equals("—")) buf.append('-');
                else if (token.equals("✓")) {
                    String ch = Words.MORSE_REV.get(buf.toString());
                    buf.setLength(0);
                    if (ch != null) {
                        emitText(ch, true);
                        updatePreview();
                        return;
                    }
                }
                if (buf.length() > 7) buf.setLength(0);
                break;
            case Layouts.M_BIN:
                if (token.equals("0") || token.equals("1")) buf.append(token);
                if (buf.length() >= 8) {
                    int v = Integer.parseInt(buf.toString(), 2);
                    buf.setLength(0);
                    updatePreview();
                    emitCodePoint(v);
                    return;
                }
                break;
            case Layouts.M_HEX:
                buf.append(token);
                if (buf.length() >= 2) {
                    int v = Integer.parseInt(buf.toString(), 16);
                    buf.setLength(0);
                    updatePreview();
                    emitCodePoint(v);
                    return;
                }
                break;
            case Layouts.M_DEC:
            case Layouts.M_UNI:
                if (token.equals("✓")) {
                    int v = -1;
                    try {
                        if (buf.length() > 0) v = Integer.parseInt(buf.toString(), layout.mode == Layouts.M_DEC ? 10 : 16);
                    } catch (NumberFormatException ignored) {
                    }
                    buf.setLength(0);
                    updatePreview();
                    emitCodePoint(v);
                    return;
                } else if (buf.length() < 7) {
                    buf.append(token);
                }
                break;
            case Layouts.M_WHEEL:
                if (token.equals("◀")) wheelIdx = (wheelIdx + WHEEL.length() - 1) % WHEEL.length();
                else if (token.equals("▶")) wheelIdx = (wheelIdx + 1) % WHEEL.length();
                else if (token.equals("⏪")) wheelIdx = (wheelIdx + WHEEL.length() - 5) % WHEEL.length();
                else if (token.equals("⏩")) wheelIdx = (wheelIdx + 5) % WHEEL.length();
                else if (token.equals("✓")) {
                    updatePreview();
                    emitText(String.valueOf(WHEEL.charAt(wheelIdx)), true);
                    return;
                }
                break;
            default:
        }
        updatePreview();
    }

    // ---- shift / space / enter / backspace

    private void shiftAct() {
        long now = SystemClock.uptimeMillis();
        if (caps) {
            caps = false;
            shift = false;
        } else if (shift && now - lastShiftTap < 400) {
            caps = true;
        } else {
            shift = !shift;
        }
        lastShiftTap = now;
        rebuildKeyboard();
    }

    private boolean isWordChar(char ch) {
        if (Character.isLetterOrDigit(ch) || ch == '\'' || Character.isSurrogate(ch)) return true;
        int t = Character.getType(ch);
        return t == Character.NON_SPACING_MARK || t == Character.ENCLOSING_MARK || t == Character.COMBINING_SPACING_MARK;
    }

    private void wordTransforms(InputConnection ic) {
        boolean any = has("word_reverse") || has("title_case") || has("yell_words") || has("emojify")
                || has("shakespeare") || has("pirate_arr") || has("autocorrect_gremlin") || has("redacted")
                || has("repeat_word") || has("filler_words");
        if (!any) return;
        CharSequence b = ic.getTextBeforeCursor(40, 0);
        if (b == null || b.length() == 0) return;
        int end = b.length(), i = end;
        while (i > 0 && isWordChar(b.charAt(i - 1))) i--;
        if (i == end) return;
        String w = b.subSequence(i, end).toString();
        String lw = w.toLowerCase(Locale.ROOT);
        String w2 = w;
        String suffix = "";
        if (has("word_reverse")) w2 = new StringBuilder(w2).reverse().toString();
        if (has("title_case") && !w2.isEmpty() && Character.isLowerCase(w2.charAt(0))) {
            w2 = w2.substring(0, 1).toUpperCase(Locale.ROOT) + w2.substring(1);
        }
        if (has("yell_words") && rnd.nextInt(100) < 10) w2 = w2.toUpperCase(Locale.ROOT);
        if (has("emojify")) {
            String e = Words.EMOJI_MAP.get(lw);
            if (e != null) w2 = e;
        }
        if (has("shakespeare")) {
            String e = Words.SHAKES.get(lw);
            if (e != null) w2 = font.apply(e);
        }
        if (has("pirate_arr")) {
            String e = Words.PIRATE.get(lw);
            if (e != null) w2 = font.apply(e);
            else if (rnd.nextInt(100) < 8) suffix += " " + font.apply("arr");
        }
        if (has("autocorrect_gremlin") && rnd.nextInt(100) < 15) {
            w2 = font.apply(Words.SILLY[rnd.nextInt(Words.SILLY.length)]);
        }
        if (has("redacted") && rnd.nextInt(100) < 12) {
            StringBuilder sb = new StringBuilder();
            int n = w.codePointCount(0, w.length());
            for (int k = 0; k < n; k++) sb.append('█');
            w2 = sb.toString();
        }
        if (has("repeat_word") && rnd.nextInt(100) < 8) w2 = w2 + " " + w2;
        if (has("filler_words") && rnd.nextInt(100) < 8) {
            suffix += " " + font.apply(Words.FILLERS[rnd.nextInt(Words.FILLERS.length)]);
        }
        if (!w2.equals(w)) {
            ic.deleteSurroundingText(w.codePointCount(0, w.length()), 0);
            ic.commitText(w2, 1);
        }
        if (!suffix.isEmpty()) ic.commitText(suffix, 1);
    }

    private void spaceAct() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        dead.clear();
        if (has("space_gremlin") && rnd.nextInt(100) < 25) {
            afterPress();
            return;
        }
        if (!isReverse()) wordTransforms(ic);
        String sp = " ";
        if (has("space_underscore")) sp = "_";
        else if (has("space_emoji")) sp = Words.EMOJIS[rnd.nextInt(Words.EMOJIS.length)];
        else if (has("space_clap")) sp = "👏";
        else if (has("space_double")) sp = "  ";
        if (has("auto_period") && sp.equals(" ") && !isReverse()) {
            CharSequence b = ic.getTextBeforeCursor(2, 0);
            if (b != null && b.length() == 2 && b.charAt(1) == ' ' && Character.isLetterOrDigit(b.charAt(0))) {
                ic.deleteSurroundingText(1, 0);
                ic.commitText(". ", 1);
                afterPress();
                return;
            }
        }
        commit(sp);
        if (has("emoji_rain") && rnd.nextInt(100) < 8) {
            commit(Words.EMOJIS[rnd.nextInt(Words.EMOJIS.length)] + " ");
        }
        if (has("haunted") && rnd.nextInt(100) < 5) commit(font.apply("boo") + " ");
        afterPress();
    }

    private void enterAct() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        dead.clear();
        EditorInfo ei = getCurrentInputEditorInfo();
        int action = ei == null ? EditorInfo.IME_ACTION_NONE : (ei.imeOptions & EditorInfo.IME_MASK_ACTION);
        boolean noAction = ei != null && (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action);
        } else {
            String s = "\n";
            if (has("enter_twice")) s = "\n\n";
            else if (has("enter_time")) s = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()) + "\n";
            else if (has("enter_fire")) s = "🔥\n";
            ic.commitText(s, 1);
        }
        afterPress();
    }

    private void backspaceAct() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (buf.length() > 0) {
            buf.deleteCharAt(buf.length() - 1);
            updatePreview();
            return;
        }
        if (has("bksp_broken") && rnd.nextBoolean()) {
            afterPress();
            return;
        }
        if (has("bksp_types")) {
            commit(font.apply(String.valueOf((char) ('a' + rnd.nextInt(26)))));
            afterPress();
            return;
        }
        if (has("bksp_sentence")) {
            CharSequence b = ic.getTextBeforeCursor(500, 0);
            if (b != null && b.length() > 0) {
                int end = b.length(), i = end;
                while (i > 0 && (Character.isWhitespace(b.charAt(i - 1)) || ".!?".indexOf(b.charAt(i - 1)) >= 0)) i--;
                while (i > 0 && ".!?\n".indexOf(b.charAt(i - 1)) < 0) i--;
                ic.deleteSurroundingText(Character.codePointCount(b, i, end), 0);
            }
        } else if (has("bksp_word")) {
            CharSequence b = ic.getTextBeforeCursor(60, 0);
            if (b != null && b.length() > 0) {
                int end = b.length(), i = end;
                while (i > 0 && Character.isWhitespace(b.charAt(i - 1))) i--;
                while (i > 0 && !Character.isWhitespace(b.charAt(i - 1))) i--;
                ic.deleteSurroundingText(Character.codePointCount(b, i, end), 0);
            }
        } else {
            sendDownUpKeyEvents(isReverse() ? KeyEvent.KEYCODE_FORWARD_DEL : KeyEvent.KEYCODE_DEL);
            if (has("bulldozer_bksp")) ic.deleteSurroundingText(1 + rnd.nextInt(4), 0);
        }
        afterPress();
    }

    // ------------------------------------------------------------ roll screen

    private TextView label(String s, float sp, int color, int gravity) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(gravity);
        return t;
    }

    private void showRollScreen() {
        if (root == null) return;
        cancelRepeat();
        overlayActive = true;
        rolled = false;
        kbRoot.setVisibility(View.GONE);
        rollOverlay.removeAllViews();
        rollOverlay.setVisibility(View.VISIBLE);
        rollOverlay.setBackgroundColor(0xFF0B0B14);
        RollState s = RollState.load(this);

        chooseMode();
        rollTitle = label(modeTitle(), 18f, modeColor(), Gravity.CENTER);
        rollTitle.setTypeface(Typeface.DEFAULT_BOLD);
        rollOverlay.addView(rollTitle, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        TextView sub = label("Roll #" + (s.rollCount + 1) + " - " + modeSub() + " No skipping.", 11f, 0xFF9999AA, Gravity.CENTER);
        rollOverlay.addView(sub, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(18)));

        ScrollView sv = new ScrollView(this);
        LinearLayout slots = new LinearLayout(this);
        slots.setOrientation(LinearLayout.VERTICAL);
        slots.setGravity(Gravity.CENTER);
        slots.setPadding(dp(14), dp(10), dp(14), dp(10));
        sv.addView(slots, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        slotVal = new TextView[1];
        TextView v = label("???", 22f, 0xFF666677, Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        slotVal[0] = v;
        slots.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        rollOverlay.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        rollBtn = label("🎲 ROLL!", 20f, 0xFFFFFFFF, Gravity.CENTER);
        rollBtn.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(0xFF6C4DFF);
        gd.setCornerRadius(dp(14));
        rollBtn.setBackground(gd);
        rollBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onRollButton();
            }
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        blp.setMargins(dp(12), dp(6), dp(12), dp(10));
        rollOverlay.addView(rollBtn, blp);
        root.requestLayout();
    }

    private void onRollButton() {
        if (!rolled) {
            rolled = true;
            rollBtn.setText("rolling...");
            rollBtn.setAlpha(0.5f);
            doRoll();
        } else if (revealed != null && allRevealed()) {
            finishRoll();
        }
    }

    private boolean allRevealed() {
        for (boolean b : revealed) if (!b) return false;
        return true;
    }

    // ---- roll modes
    private static final int RM_NORMAL = 0, RM_MULTI = 1, RM_ULTRA = 2, RM_LUCK = 3, RM_CB = 4, RM_ALLRAR = 5,
            RM_FULLBLESS = 6, RM_MEGA = 7, RM_DEVILISH = 8, RM_LUCKYMULTI = 9, RM_DEVILDOZEN = 10, RM_TRIPLEBLESS = 11;

    private int rollMode;
    private final List<Item> curItems = new ArrayList<>();
    private final List<String> curKinds = new ArrayList<>();
    private final List<String> curEffects = new ArrayList<>();
    private final List<Integer> curBless = new ArrayList<>();
    private final List<String> curBlessEffects = new ArrayList<>();
    private Rarity curBest = Rarity.COMMON;
    private boolean blessed;
    private boolean cbBless;

    private void chooseMode() {
        int[] w = {15, 15, 30, 30, 40, 40, 40, 30, 80, 90, 110};
        int[] m = {RM_MEGA, RM_DEVILDOZEN, RM_ULTRA, RM_FULLBLESS, RM_ALLRAR, RM_DEVILISH, RM_LUCKYMULTI,
                RM_TRIPLEBLESS, RM_CB, RM_LUCK, RM_MULTI};
        int x = rnd.nextInt(1000);
        rollMode = RM_NORMAL;
        int acc = 0;
        for (int i = 0; i < w.length; i++) {
            acc += w[i];
            if (x < acc) {
                rollMode = m[i];
                break;
            }
        }
        cbBless = rollMode == RM_CB && rnd.nextBoolean();
    }

    private boolean blessMode() {
        return rollMode == RM_FULLBLESS || rollMode == RM_TRIPLEBLESS || cbBless;
    }

    private int modeCount() {
        switch (rollMode) {
            case RM_MULTI: return 6;
            case RM_ULTRA: return 12;
            case RM_MEGA: return 30;
            case RM_ALLRAR: return Rarity.values().length;
            case RM_LUCKYMULTI: return 6;
            case RM_DEVILDOZEN: return 12;
            case RM_TRIPLEBLESS: return 3;
            default: return 1;
        }
    }

    private String modeTitle() {
        switch (rollMode) {
            case RM_MULTI: return "🎲🎲 MULTI ROLL! 6 SLOTS";
            case RM_ULTRA: return "🌟 ULTRA ROLL! 12 SLOTS";
            case RM_LUCK: return "🍀 LUCK ROLL! RARE+ ONLY";
            case RM_CB: return "☯ CURSED OR BLESSED";
            case RM_ALLRAR: return "🌈 ALL-RARITY ROLL! 1 PER TIER";
            case RM_FULLBLESS: return "😇 FULL BLESSING! BACK TO DEFAULT";
            case RM_MEGA: return "💥 MEGA MULTI! 30 SLOTS";
            case RM_DEVILISH: return "😈 DEVILISH ROLL! PRANKS ONLY";
            case RM_LUCKYMULTI: return "🍀🍀 LUCKY MULTI! 6x RARE+";
            case RM_DEVILDOZEN: return "👿 DEVIL'S DOZEN! 12 PRANKS";
            case RM_TRIPLEBLESS: return "🙏 TRIPLE BLESSING! 3 CLEANSES";
            default: return "🎲 ROLL YOUR KEYBOARD";
        }
    }

    private int modeColor() {
        switch (rollMode) {
            case RM_MULTI: return 0xFFFFA000;
            case RM_ULTRA: return 0xFFFF1744;
            case RM_LUCK: return 0xFF39FF14;
            case RM_CB: return 0xFFB388FF;
            case RM_ALLRAR: return 0xFF40C4FF;
            case RM_FULLBLESS:
            case RM_TRIPLEBLESS: return 0xFFFFE082;
            case RM_MEGA: return 0xFFFF9100;
            case RM_DEVILISH:
            case RM_DEVILDOZEN: return 0xFFD500F9;
            case RM_LUCKYMULTI: return 0xFF69F0AE;
            default: return 0xFFFFFFFF;
        }
    }

    private String modeSub() {
        switch (rollMode) {
            case RM_MULTI: return "6 rolls at once, all applied.";
            case RM_ULTRA: return "12 rolls at once, all applied.";
            case RM_LUCK: return "this roll can only land on Rare or better.";
            case RM_CB: return "50% a Cursed roll, 50% a Blessing that only restores or cleanses.";
            case RM_ALLRAR: return "one roll from every rarity tier, all applied.";
            case RM_FULLBLESS: return "everything gets reset to the default keyboard.";
            case RM_MEGA: return "30 rolls at once, all applied. Scroll to see them all.";
            case RM_DEVILISH: return "this roll can only be a Devilish prank.";
            case RM_LUCKYMULTI: return "6 rolls at once, each Rare or better.";
            case RM_DEVILDOZEN: return "12 rolls, all Devilish or Cursed. Sorry.";
            case RM_TRIPLEBLESS: return "3 random blessings, each restores or cleanses.";
            default: return "one slot, " + Roller.all().size() + " possible results.";
        }
    }

    private Item pickForSlot(int i) {
        switch (rollMode) {
            case RM_LUCK:
            case RM_LUCKYMULTI: return Roller.pickAtLeast(rnd, Rarity.RARE);
            case RM_CB: return Roller.pickOfRarity(rnd, Rarity.CURSED);
            case RM_ALLRAR: return Roller.pickOfRarity(rnd, Rarity.values()[i % Rarity.values().length]);
            case RM_DEVILISH: return Roller.pickOfRarity(rnd, Rarity.DEVILISH);
            case RM_DEVILDOZEN: return Roller.pickOfRarity(rnd, rnd.nextBoolean() ? Rarity.DEVILISH : Rarity.CURSED);
            default: return Roller.pickAny(rnd);
        }
    }

    private void doRoll() {
        st = RollState.load(this);
        int base = st.rollCount;
        curItems.clear();
        curKinds.clear();
        curEffects.clear();
        curBless.clear();
        curBlessEffects.clear();
        curBest = Rarity.COMMON;
        Set<String> disc = new HashSet<>();
        blessed = blessMode();
        int n = modeCount();
        for (int i = 0; i < n; i++) {
            if (blessed) {
                int idx = rollMode == RM_FULLBLESS ? 0 : rnd.nextInt(Blessings.NAMES.length);
                curBless.add(idx);
                curBlessEffects.add(st.applyBlessing(idx, rnd));
            } else {
                Item it = pickForSlot(i);
                String kind = Roller.kindOf(it);
                curItems.add(it);
                curKinds.add(kind);
                curEffects.add(st.applyItem(it, rnd));
                disc.add(RollState.discoverKey(kind, it.id));
                if (it.rarity.ordinal() > curBest.ordinal()) curBest = it.rarity;
            }
        }
        st.rollCount = base + 1;
        st.pending = false;
        st.saveRoll(this);
        if (!disc.isEmpty()) RollState.discover(this, disc);
        revealed = new boolean[1];
        spinStart = SystemClock.uptimeMillis();
        h.post(spinRunnable);
    }

    private final Runnable spinRunnable = new Runnable() {
        @Override
        public void run() {
            long t = SystemClock.uptimeMillis() - spinStart;
            int n = modeCount();
            long total = n == 1 ? 2800 : (n <= 8 ? 3200 : (n <= 12 ? 3800 : 4500));
            if (t >= total) {
                revealed[0] = true;
                showSlot();
                if (rollOverlay != null) rollOverlay.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                finishReveal();
            } else {
                spinSlot();
                h.postDelayed(this, 45 + t / 25);
            }
        }
    };

    private float slotTextSize(int n) {
        return n == 1 ? 22f : (n <= 8 ? 14f : (n <= 12 ? 12f : 10f));
    }

    private void spinSlot() {
        int n = modeCount();
        SpannableStringBuilder sb = new SpannableStringBuilder();
        for (int i = 0; i < n; i++) {
            if (i > 0) sb.append("\n");
            if (blessMode() || (rollMode == RM_CB && rnd.nextBoolean())) {
                sb.append(colored(Blessings.NAMES[rnd.nextInt(Blessings.NAMES.length)], 0xFFFFE082));
            } else {
                Item it = pickForSlot(i);
                sb.append(colored(it.name, it.rarity.color));
            }
        }
        slotVal[0].setTextSize(slotTextSize(n));
        slotVal[0].setText(sb);
    }

    private SpannableStringBuilder colored(String s, int color) {
        SpannableStringBuilder sb = new SpannableStringBuilder(s);
        sb.setSpan(new ForegroundColorSpan(color), 0, s.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return sb;
    }

    private void showSlot() {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (blessed) {
            int n = curBless.size();
            slotVal[0].setTextSize(slotTextSize(n));
            if (n == 1) {
                sb.append(colored(Blessings.NAMES[curBless.get(0)], 0xFFFFE082));
                sb.append(colored("\nBLESSED", 0xFFFFE082));
                sb.append(colored("\n\n" + curBlessEffects.get(0), 0xFFBBBBCC));
            } else {
                for (int i = 0; i < n; i++) {
                    if (i > 0) sb.append("\n");
                    sb.append(colored("😇 " + Blessings.NAMES[curBless.get(i)] + ": " + curBlessEffects.get(i), 0xFFFFE082));
                }
            }
        } else if (curItems.size() == 1) {
            Item it = curItems.get(0);
            slotVal[0].setTextSize(22f);
            sb.append(colored(it.name, it.rarity.color));
            sb.append(colored("\n" + it.rarity.label.toUpperCase(Locale.ROOT) + " " + Roller.kindLabel(curKinds.get(0)), it.rarity.color));
            if (it instanceof FontDef) sb.append(colored("\n" + ((FontDef) it).apply("Hello 123"), 0xFFFFFFFF));
            sb.append(colored("\n\n" + curEffects.get(0), 0xFFBBBBCC));
        } else {
            int n = curItems.size();
            slotVal[0].setTextSize(slotTextSize(n));
            for (int i = 0; i < n; i++) {
                Item it = curItems.get(i);
                if (i > 0) sb.append("\n");
                sb.append(colored("• " + it.name + "  [" + it.rarity.label + " " + Roller.kindLabel(curKinds.get(i)) + "]",
                        it.rarity.color));
            }
            sb.append(colored("\n\nAll applied in order. A feature rolled twice switches back off.", 0xFFBBBBCC));
        }
        slotVal[0].setText(sb);
    }

    private void finishReveal() {
        if (blessed) {
            rollTitle.setText("😇 BLESSED 😇");
            rollTitle.setTextColor(0xFFFFE082);
        } else if (rollMode == RM_CB) {
            rollTitle.setText("😈 CURSED 😈");
            rollTitle.setTextColor(Rarity.CURSED.color);
        } else {
            String prefix;
            switch (rollMode) {
                case RM_MULTI: prefix = "MULTI "; break;
                case RM_ULTRA: prefix = "ULTRA "; break;
                case RM_LUCK: prefix = "LUCK "; break;
                case RM_ALLRAR: prefix = "ALL-RARITY "; break;
                case RM_MEGA: prefix = "MEGA "; break;
                case RM_LUCKYMULTI: prefix = "LUCKY "; break;
                case RM_DEVILDOZEN: prefix = "DEVIL'S DOZEN "; break;
                default: prefix = "";
            }
            rollTitle.setText("★ " + prefix + curBest.label.toUpperCase(Locale.ROOT) + " ★");
            rollTitle.setTextColor(curBest.color);
        }
        rollBtn.setText("✔ KEEP THIS KEYBOARD");
        rollBtn.setAlpha(1f);
    }

    private void finishRoll() {
        overlayActive = false;
        rolled = false;
        shift = false;
        caps = false;
        page = 0;
        buf.setLength(0);
        wheelIdx = 0;
        loadConfig();
        rebuildKeyboard();
        if (wantAutoShift()) {
            shift = true;
            rebuildKeyboard();
        }
    }
}
