package com.rollkeyboard;

import java.util.ArrayList;
import java.util.List;

import static com.rollkeyboard.Rarity.*;

public final class Features {
    private Features() {}

    public static final List<Item> ALL = new ArrayList<>();

    private static void f(String id, String name, Rarity r, String group) {
        ALL.add(new Item(id, name, r, group));
    }

    public static Item byId(String id) {
        for (Item i : ALL) if (i.id.equals(id)) return i;
        return null;
    }

    static {
        // case
        f("auto_cap", "Auto-capitalize sentences", COMMON, null);
        f("caps_lock", "ALL CAPS forever", UNCOMMON, "case");
        f("lower_only", "all lowercase forever", UNCOMMON, "case");
        f("title_case", "Auto Title Case words", UNCOMMON, null);
        f("spongebob", "sPoNgEcAsE", RARE, "case");
        f("random_case", "RaNdOm cAsE", RARE, "case");
        f("inverted_shift", "Inverted shift (caps by default)", RARE, "case");
        // typing chaos
        f("typo_swap", "Fat Fingers (swaps letters 10%)", UNCOMMON, null);
        f("neighbor_drift", "Neighbor Drift (hits adjacent key 8%)", UNCOMMON, null);
        f("ghost_press", "Ghost Presses (7% of taps ignored)", UNCOMMON, null);
        f("stuck_keys", "Sticky Keys (10% repeat x3)", RARE, null);
        f("double_letters", "Double Trouble (every key twice)", RARE, "rep");
        f("triple_letters", "Triple Threat (every key x3)", EPIC, "rep");
        f("mirror_hand", "Mirror Hand (types opposite key)", EPIC, null);
        f("vowel_cycle", "Vowel Cycle (a>e>i>o>u>a)", RARE, "vowel");
        f("vowel_star", "Vowel Redactor (vowels become *)", RARE, "vowel");
        f("vowel_ghost", "Vowel Void (vowels vanish)", EPIC, "vowel");
        f("caesar1", "Caesar +1 cipher", RARE, "cipher");
        f("atbash", "Atbash mirror alphabet", EPIC, "cipher");
        f("rot13", "ROT13 cipher", EPIC, "cipher");
        f("uwu", "UwU filter (r and l become w)", RARE, null);
        f("double_tap", "Double-Tap Required", EPIC, null);
        f("cooldown", "Cooldown (350ms between taps)", RARE, null);
        f("laggy", "Laggy Keyboard (600ms delay)", EPIC, null);
        f("reverse_typing", "Reverse Typing (text grows backwards)", LEGENDARY, null);
        f("shuffle_after", "Shuffle keys after every press", LEGENDARY, null);
        f("liar_labels", "Liar Keys (labels are lies)", LEGENDARY, "label");
        f("blind_keys", "Blind Keys (no labels)", EPIC, "label");
        f("numbers_words", "Number Words (1 types one)", UNCOMMON, null);
        // space / enter / backspace
        f("space_underscore", "Space types _", UNCOMMON, "space");
        f("space_double", "Space types two spaces", UNCOMMON, "space");
        f("space_clap", "Clap Back (space = clap)", RARE, "space");
        f("space_emoji", "Space types a random emoji", EPIC, "space");
        f("auto_period", "Double-space makes a period", COMMON, null);
        f("enter_fire", "Enter adds a fire emoji", UNCOMMON, "enter");
        f("enter_twice", "Enter x2", UNCOMMON, "enter");
        f("enter_time", "Enter stamps the time", RARE, "enter");
        f("bksp_word", "Backspace nukes a whole word", RARE, "bksp");
        f("bksp_broken", "Backspace jams 50% of the time", EPIC, "bksp");
        f("bksp_types", "Backspace types random letters", LEGENDARY, "bksp");
        f("bksp_sentence", "Backspace deletes a sentence", MYTHIC, "bksp");
        // word transforms
        f("yell_words", "Random SHOUTING words", UNCOMMON, null);
        f("emojify", "Emojify words", RARE, null);
        f("pirate_arr", "Pirate mode (arr!)", RARE, null);
        f("shakespeare", "Thou-ify (Shakespeare)", RARE, null);
        f("repeat_word", "Stutter (repeats words)", RARE, null);
        f("filler_words", "Filler words (um, like)", RARE, null);
        f("redacted", "Redacted (random words become blocks)", EPIC, null);
        f("autocorrect_gremlin", "Autocorrect Gremlin", EPIC, null);
        f("word_reverse", "Word Reverser", LEGENDARY, null);
        // punctuation
        f("dots_spam", "Dot Dot Dot (. becomes ...)", UNCOMMON, null);
        f("bang_spam", "!!! (! becomes !!!)", UNCOMMON, null);
        f("exclaim", "Excited (. becomes !)", UNCOMMON, "endp");
        f("question_inv", "Spanish Questions (? gets an upside-down one)", RARE, null);
        f("uptalk", "Uptalk (. becomes ?)", EPIC, "endp");
        // extras
        f("emoji_rain", "Emoji Rain (random emoji after words)", UNCOMMON, null);
        f("haunted", "Haunted (random boo)", RARE, null);
        // ui bars
        f("number_row", "Number row", COMMON, null);
        f("keystroke_counter", "Keystroke counter", COMMON, null);
        f("paste_key", "Paste key", COMMON, null);
        f("emoji_row", "Emoji row", UNCOMMON, null);
        f("cursor_keys", "Cursor keys row", UNCOMMON, null);
        f("edit_bar", "Edit bar (select all / copy / cut / paste)", UNCOMMON, null);
        f("suggestions", "Cursed Suggestion Bar", RARE, null);
        // orientation
        f("tilted_kb", "Tilted keyboard", RARE, "orient");
        f("mirrored_kb", "Mirrored keyboard", EPIC, "orient");
        f("upside_down", "Upside-down keyboard", LEGENDARY, "orient");
        f("drunk_keys", "Drunk Keys (every key crooked)", EPIC, null);
        // size
        f("tiny_kb", "Tiny keyboard", UNCOMMON, "size");
        f("tall_kb", "Tall keyboard", UNCOMMON, "size");
        f("flat_kb", "Flat keyboard", RARE, "size");
        f("huge_kb", "Huge keyboard", RARE, "size");
        // shape
        f("round_keys", "Round keys", COMMON, "shape");
        f("sharp_keys", "Sharp keys", COMMON, "shape");
        f("pill_keys", "Pill keys", UNCOMMON, "shape");
        f("gapless", "Gapless keys", UNCOMMON, "shape");
        f("chunky_gaps", "Chunky gaps", RARE, "shape");
        // feedback
        f("haptics_off", "No haptics", COMMON, "haptic");
        f("haptics_strong", "Strong haptics", UNCOMMON, "haptic");
        f("click_sound", "Click sounds", COMMON, "sound");
        f("beep_orchestra", "Beep Orchestra (random tones)", RARE, "sound");
        f("turbo_repeat", "Hold any key to repeat", UNCOMMON, null);
        // colors
        f("rainbow_keys", "Rainbow keys", RARE, "kcolor");
        f("strobe_keys", "Strobe keys (recolor every press)", LEGENDARY, "kcolor");
        // doom
        f("chaos_mode", "CHAOS MODE (2% per key: forced reroll)", MYTHIC, null);
    }
}
