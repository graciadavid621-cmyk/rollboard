package com.rollkeyboard;

public enum Rarity {
    COMMON("Common", 0xFFB0B0B0, 44),
    UNCOMMON("Uncommon", 0xFF4CAF50, 26),
    RARE("Rare", 0xFF2196F3, 15),
    EPIC("Epic", 0xFFAB47BC, 8),
    LEGENDARY("Legendary", 0xFFFFA000, 4),
    MYTHIC("Mythic", 0xFFFF1744, 2),
    CURSED("Cursed", 0xFF39FF14, 1);

    public final String label;
    public final int color;
    public final double weight;

    Rarity(String label, int color, double weight) {
        this.label = label;
        this.color = color;
        this.weight = weight;
    }
}
