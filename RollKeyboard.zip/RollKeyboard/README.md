# Roll Keyboard

An Android keyboard (IME) that makes you roll for your keyboard.

- On first switching to it, and randomly (default 30%, adjustable in the app) when it opens, you get a roll screen you can't skip.
- A roll picks: a layout, a unicode font, how many letter keys go missing, which special keys go missing, a set of features, and a color theme. Everything is persistent until the next roll.
- Rarities: Common, Uncommon, Rare, Epic, Legendary, Mythic, Cursed. 365 items in total.
- The toolbar always has a globe (switch keyboard) and a dice (reroll) button.

## Build
Push to GitHub. The workflow in `.github/workflows/build.yml` builds the debug APK and attaches it to a release.
Local: `gradle assembleDebug` (Gradle 8.7, JDK 17).
